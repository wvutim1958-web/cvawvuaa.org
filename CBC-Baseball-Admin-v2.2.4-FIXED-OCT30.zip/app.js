// CBC Baseball Management System - Main Application
// Data Storage
let players = [];
let coaches = [];  // Separate database for coaches
let teams = [];
let documents = [];
let associations = [
    "Chester", "Clover Hill", "Colonial Heights", "Gates", "Gordon", "Hening",
    "Jacobs", "Matoaca", "Midlothian", "Moseley", "Old Hundred", "Providence",
    "Salem", "Scott", "Smith", "Spring Run", "Swift Creek", "Wells", "Woolridge"
];

// Load data from localStorage on startup
window.addEventListener('DOMContentLoaded', () => {
    loadData();
    initializeApp();
    updateDashboard();
    populateFilters();
});

function initializeApp() {
    // Tab switching
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const tabId = btn.dataset.tab;
            switchTab(tabId);
        });
    });

    // File upload
    const fileInput = document.getElementById('file-input');
    const uploadArea = document.getElementById('upload-area');

    fileInput.addEventListener('change', (e) => {
        handleFiles(e.target.files);
    });

    // Drag and drop
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.classList.add('drag-over');
    });

    uploadArea.addEventListener('dragleave', () => {
        uploadArea.classList.remove('drag-over');
    });

    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('drag-over');
        handleFiles(e.dataTransfer.files);
    });

    // Document upload handling
    const docInput = document.getElementById('doc-input');
    const docUploadArea = document.getElementById('doc-upload-area');
    
    if (docInput && docUploadArea) {
        docInput.addEventListener('change', (e) => {
            handleDocumentUpload(e.target.files);
        });

        docUploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            docUploadArea.classList.add('drag-over');
        });

        docUploadArea.addEventListener('dragleave', () => {
            docUploadArea.classList.remove('drag-over');
        });

        docUploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            docUploadArea.classList.remove('drag-over');
            handleDocumentUpload(e.dataTransfer.files);
        });
    }

    // Player search
    document.getElementById('player-search').addEventListener('input', filterPlayers);
    
    // Filter dropdowns
    document.getElementById('filter-association').addEventListener('change', filterPlayers);
    document.getElementById('filter-league').addEventListener('change', filterPlayers);
    document.getElementById('filter-year').addEventListener('change', filterPlayers);
    document.getElementById('filter-status').addEventListener('change', filterPlayers);
    
    // Coach search and filters
    document.getElementById('coach-search').addEventListener('input', filterCoaches);
    document.getElementById('filter-coach-association').addEventListener('change', filterCoaches);
    document.getElementById('filter-coach-league').addEventListener('change', filterCoaches);
    document.getElementById('filter-coach-year').addEventListener('change', filterCoaches);
}

function switchTab(tabId) {
    // Update buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');

    // Update content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(tabId).classList.add('active');

    // Refresh data if needed
    if (tabId === 'players') {
        displayPlayers(players);
    } else if (tabId === 'coaches') {
        displayCoaches(coaches);
    } else if (tabId === 'teams') {
        displayTeams();
    } else if (tabId === 'dashboard') {
        updateDashboard();
    } else if (tabId === 'documents') {
        displayDocuments();
    }
}

// Helper function to capitalize each word
function capitalizeWords(str) {
    return str.split(/[\s-]+/).map(word => 
        word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
    ).join(' ');
}

// File handling - Excel import with SheetJS
function handleFiles(files) {
    const importLog = document.getElementById('import-log');
    const importResults = document.getElementById('import-results');
    
    importLog.innerHTML = '<div class="log-info">📥 Processing files...</div>';
    importResults.style.display = 'block';

    let filesProcessed = 0;
    let playersImported = 0;

    Array.from(files).forEach(file => {
        if (file.name.endsWith('.xlsx') || file.name.endsWith('.xlsm') || file.name.endsWith('.xls')) {
            importLog.innerHTML += `<div class="log-info">📖 Reading: ${file.name}</div>`;
            
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const data = new Uint8Array(e.target.result);
                    const workbook = XLSX.read(data, { type: 'array' });
                    
                    // Look for "Data Entry" sheet (CBC roster template format)
                    const sheetName = workbook.SheetNames.find(name => 
                        name.toLowerCase().includes('data entry') || 
                        name.toLowerCase().includes('roster')
                    ) || workbook.SheetNames[0];
                    
                    const worksheet = workbook.Sheets[sheetName];
                    const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
                    
                    // PARSE FILENAME: Expected format is YYYY-cbc-association-league-coach.xlsm
                    // Example: 2025-cbc-scott-pinto-fischer.xlsm
                    const filenameParts = file.name.replace(/\.(xlsx|xlsm|xls)$/i, '').split('-');
                    let filenameData = null;
                    
                    if (filenameParts.length >= 5 && filenameParts[1].toLowerCase() === 'cbc') {
                        const yearFromFile = parseInt(filenameParts[0]);
                        const associationFromFile = capitalizeWords(filenameParts[2]);
                        const leagueFromFile = capitalizeWords(filenameParts[3]);
                        const coachFromFile = capitalizeWords(filenameParts[4]);
                        
                        filenameData = {
                            year: yearFromFile,
                            association: associationFromFile,
                            league: leagueFromFile,
                            teamName: coachFromFile
                        };
                        
                        importLog.innerHTML += `<div class="log-success">✅ Filename parsed: ${yearFromFile} | ${associationFromFile} | ${leagueFromFile} | Team ${coachFromFile}</div>`;
                    } else {
                        importLog.innerHTML += `<div class="log-warning">⚠️ Filename not in standard format (YYYY-cbc-association-league-coach). Will use Excel data.</div>`;
                    }
                    
                    // Extract association, league, year from top cells (CBC template format) - use as fallback
                    let association = filenameData?.association || (jsonData[2] ? jsonData[2][1] : 'Unknown');
                    let league = filenameData?.league || (jsonData[3] ? jsonData[3][1] : 'Unknown');
                    let year = filenameData?.year || (jsonData[4] ? jsonData[4][1] : new Date().getFullYear());
                    
                    // Get team name - prioritize filename, fallback to coach detection
                    let teamName = filenameData?.teamName || '';
                    let division = '';
                    
                    // Only scan for coach if teamName not from filename
                    if (!teamName) {
                        console.log(`\n=== Scanning ${file.name} for coach ===`);
                        for (let i = 7; i < jsonData.length; i++) {
                        const row = jsonData[i];
                        if (!row || row.length < 5) continue;
                        const firstName = String(row[2] || '').trim();
                        const lastName = String(row[4] || '').trim();
                        const dobValue = row[10];
                        
                        // Debug: Log each row we're examining
                        if (firstName || lastName) {
                            console.log(`Row ${i}: "${firstName}" "${lastName}" | DOB: ${dobValue ? `"${dobValue}"` : 'EMPTY'}`);
                        }
                        
                        if (!firstName && !lastName) continue;
                        
                        // Skip header rows, markers, and single-character values
                        if (firstName.toUpperCase().includes('FIRST') || 
                            lastName.toUpperCase().includes('LAST') ||
                            lastName.toUpperCase() === 'FA' ||
                            firstName.toUpperCase() === 'FA' ||
                            lastName.toUpperCase() === 'X' ||
                            firstName.toUpperCase() === 'X' ||
                            lastName.length <= 1) {  // Skip single character last names
                            console.log(`  ⏭️ Skipped (header/marker): ${firstName} ${lastName}`);
                            continue;
                        }
                        
                        // Check if this is a coach (no DOB in column K, or DOB column has email)
                        const dobString = String(dobValue || '').trim();
                        const isEmail = dobString.includes('@') || dobString.includes('.com') || dobString.includes('.net');
                        
                        if (!dobValue || dobValue === '' || isEmail) {
                            // This is a coach - use their last name for team name (only if valid)
                            if (lastName && lastName.length > 1) {
                                teamName = lastName;
                                console.log(`✅ Found team coach: ${firstName} ${lastName} (Team: ${teamName})`);
                                break;
                            }
                        }
                    }
                    } // End coach scanning loop
                    
                    if (!teamName) {
                        console.warn(`⚠️ No coach found for ${file.name}!`);
                    }
                    
                    // For Mustang, Bronco, Pony - prompt for division
                    if (league && (league.toLowerCase().includes('mustang') || 
                                  league.toLowerCase().includes('bronco') || 
                                  league.toLowerCase().includes('pony'))) {
                        const divPrompt = prompt(`Enter division for ${association} ${league} ${teamName}:\n\n• American\n• National\n\n(Leave blank if not applicable)`, '');
                        if (divPrompt) {
                            division = divPrompt.trim();
                        }
                    }
                    
                    // Parse players starting from row 8 (after headers in row 7)
                    const result = parsePlayersFromExcel(jsonData, association, league, year, teamName, division);
                    
                    filesProcessed++;
                    playersImported += result.added;
                    
                    // Determine status message
                    const currentYear = new Date().getFullYear();
                    const uploadYear = parseInt(year);
                    const statusMsg = uploadYear >= currentYear 
                        ? '🟢 Status: ACTIVE (current/future season)' 
                        : '🔴 Status: INACTIVE (historical data)';
                    
                    const teamFullName = teamName ? `${association} ${league} ${teamName}` : `${association} ${league}`;
                    importLog.innerHTML += `<div class="log-success">✅ Imported ${result.added} new players from ${file.name}</div>`;
                    if (result.coachesAdded > 0) {
                        importLog.innerHTML += `<div class="log-info">   👨‍🏫 Added ${result.coachesAdded} coaches to coach database</div>`;
                    }
                    if (result.duplicates > 0) {
                        importLog.innerHTML += `<div class="log-info">   ⚠️ Skipped ${result.duplicates} duplicate players</div>`;
                    }
                    importLog.innerHTML += `<div class="log-info">   Team: ${teamFullName} | Year: ${year}</div>`;
                    importLog.innerHTML += `<div class="log-info">   ${statusMsg}</div>`;
                    
                    // Update displays
                    saveData();
                    updateDashboard();
                    displayPlayers(players);
                    displayTeams();
                    
                } catch (error) {
                    importLog.innerHTML += `<div class="log-error">❌ Error reading ${file.name}: ${error.message}</div>`;
                }
                
                // Show final summary
                if (filesProcessed === files.length) {
                    importLog.innerHTML += `<div class="log-success">🎉 Import complete! ${playersImported} total players added.</div>`;
                }
            };
            
            reader.onerror = () => {
                importLog.innerHTML += `<div class="log-error">❌ Failed to read file: ${file.name}</div>`;
            };
            
            reader.readAsArrayBuffer(file);
            
        } else if (file.name.endsWith('.pdf')) {
            importLog.innerHTML += `<div class="log-warning">⚠️ PDF file detected: ${file.name}</div>`;
            importLog.innerHTML += `<div class="log-info">📄 <strong>To import from PDF:</strong><br>
                1. Convert PDF to Excel first using one of these methods:<br>
                &nbsp;&nbsp;&nbsp;• <a href="https://www.adobe.com/acrobat/online/pdf-to-excel.html" target="_blank">Adobe PDF to Excel</a><br>
                &nbsp;&nbsp;&nbsp;• In Excel: Data → Get Data → From File → From PDF<br>
                &nbsp;&nbsp;&nbsp;• Google Drive: Upload PDF → Open with Google Sheets → Download as Excel<br>
                2. Then upload the Excel file here<br>
                <em>Direct PDF import is not yet supported due to format variations</em>
            </div>`;
        } else {
            importLog.innerHTML += `<div class="log-error">❌ Unsupported file: ${file.name}</div>`;
        }
    });

    importLog.innerHTML += `<div class="log-success">✅ Import processing complete</div>`;
}

// Convert Excel date number to JavaScript Date
function excelDateToJSDate(excelDate) {
    if (!excelDate) return '';
    
    // Debug: log the raw value
    console.log('Excel date input:', excelDate, 'Type:', typeof excelDate);
    
    // If it's already a string date, return it
    if (typeof excelDate === 'string') {
        // Check if it's a valid date string
        if (excelDate.includes('-') || excelDate.includes('/')) {
            console.log('Returning string date:', excelDate);
            return excelDate;
        }
    }
    
    // If it's a number (Excel date serial number)
    if (typeof excelDate === 'number') {
        // Excel dates are days since 1899-12-30 (but Excel thinks 1900 was a leap year)
        // JavaScript Date epoch is 1970-01-01
        // 25569 is the number of days between 1899-12-30 and 1970-01-01
        const jsDate = new Date(Math.round((excelDate - 25569) * 86400 * 1000));
        
        // Format as YYYY-MM-DD
        const year = jsDate.getUTCFullYear();
        const month = String(jsDate.getUTCMonth() + 1).padStart(2, '0');
        const day = String(jsDate.getUTCDate()).padStart(2, '0');
        
        const result = `${year}-${month}-${day}`;
        console.log('Converted Excel date', excelDate, 'to', result);
        return result;
    }
    
    return '';
}

// Calculate league age based on CBC rules
// League age = player's age on April 30, 2026
function calculateLeagueAge(dobString) {
    if (!dobString) return '';
    
    const dob = new Date(dobString);
    const cutoffDate = new Date('2026-04-30');
    
    // Calculate age on April 30, 2026
    let age = cutoffDate.getFullYear() - dob.getFullYear();
    const monthDiff = cutoffDate.getMonth() - dob.getMonth();
    const dayDiff = cutoffDate.getDate() - dob.getDate();
    
    // If birthday hasn't occurred yet by April 30, subtract 1
    if (monthDiff < 0 || (monthDiff === 0 && dayDiff < 0)) {
        age--;
    }
    
    return age;
}

// Parse player data from Excel sheet (CBC template format)
function parsePlayersFromExcel(jsonData, association, league, year, teamName, division) {
    let added = 0;
    let duplicates = 0;
    let coachesAdded = 0;
    
    // CBC template has headers in row 7 (index 6), data starts row 8 (index 7)
    // Arrays are 0-based, so Column A = index 0, Column B = index 1, etc.
    for (let i = 7; i < jsonData.length; i++) {
        const row = jsonData[i];
        
        // Skip if row is empty or missing required fields (check columns C and E for names)
        if (!row || row.length < 5) continue;
        
        const firstName = String(row[2] || '').trim();  // Column C (index 2)
        const lastName = String(row[4] || '').trim();    // Column E (index 4)
        
        // Skip rows with no name data
        if (!firstName && !lastName) continue;
        
        // Skip header rows, markers, and single-character names
        if (firstName.toUpperCase().includes('FIRST') || 
            lastName.toUpperCase().includes('LAST') ||
            lastName.toUpperCase() === 'FA' ||
            firstName.toUpperCase() === 'FA' ||
            lastName.toUpperCase() === 'X' ||
            firstName.toUpperCase() === 'X' ||
            lastName.length <= 1) {
            continue;
        }
        
        const dob = excelDateToJSDate(row[10]);
        const coachNum = String(row[0] || '').trim();  // Column A - could be player# or coach#
        
        // Detect coaches: No birthdate (empty DOB field) OR DOB field contains email
        // Coaches don't have birthdates in the roster - this is the key identifier
        const dobValue = row[10];
        const dobString = String(dobValue || '').trim();
        const hasEmail = dobString.includes('@') || dobString.includes('.com') || dobString.includes('.net');
        const isCoach = !dob || dob === '' || hasEmail;
        
        if (isCoach) {
            // Add to coaches database
            const coach = {
                id: generatePlayerId(),
                coachNum: coachNum,
                firstName: firstName,
                middleInitial: row[3] || '',
                lastName: lastName,
                address: row[5] || '',
                city: row[6] || '',
                state: row[7] || 'VA',
                zip: row[8] || '',
                phone: row[9] || '',
                association: association,
                league: league,
                year: year,
                email: row[18] || '',
                notes: row[17] || '',
                addedDate: new Date().toISOString()
            };
            coaches.push(coach);
            coachesAdded++;
            console.log(`Added coach: ${firstName} ${lastName} (Coach #${coachNum})`);
            continue;
        }
        
        // Check for duplicates - same first name, last name, DOB, and association
        const existingPlayer = players.find(existing => 
            existing.firstName.toUpperCase() === firstName.toUpperCase() &&
            existing.lastName.toUpperCase() === lastName.toUpperCase() &&
            existing.dob === dob &&
            existing.association.toUpperCase() === association.toUpperCase()
        );
        
        if (existingPlayer) {
            // Check if they're playing in the same year (true duplicate)
            if (existingPlayer.seasons && existingPlayer.seasons.some(s => s.year === year)) {
                duplicates++;
                console.log(`Skipping duplicate: ${firstName} ${lastName} (${dob}) - already in ${year}`);
                continue;
            } else {
                // Returning player! Add new season and reactivate
                if (!existingPlayer.seasons) {
                    existingPlayer.seasons = [{
                        year: existingPlayer.year,
                        league: existingPlayer.league,
                        playerNum: existingPlayer.playerNum,
                        unifNum: existingPlayer.unifNum,
                        age: existingPlayer.age
                    }];
                }
                existingPlayer.seasons.push({
                    year: year,
                    league: league,
                    playerNum: row[0] || '',
                    unifNum: row[1] || '',
                    age: calculateLeagueAge(dob),
                    teamName: teamName || '',
                    division: division || ''
                });
                existingPlayer.year = year;  // Update to current year
                existingPlayer.league = league;
                existingPlayer.teamName = teamName || '';
                existingPlayer.division = division || '';
                existingPlayer.playerNum = row[0] || '';
                existingPlayer.unifNum = row[1] || '';
                existingPlayer.age = calculateLeagueAge(dob);
                
                // Auto-set status based on year being uploaded
                const currentYear = new Date().getFullYear();
                const uploadYear = parseInt(year);
                existingPlayer.status = uploadYear >= currentYear ? 'active' : 'inactive';
                
                existingPlayer.lastPlayedYear = year;
                added++;
                console.log(`✅ Reactivated returning player: ${firstName} ${lastName} (now playing in ${year}) - Status: ${existingPlayer.status}`);
                continue;
            }
        }
        
        const player = {
            id: generatePlayerId(),
            playerNum: row[0] || '',          // Column A - Player# (index 0)
            unifNum: row[1] || '',            // Column B - UnifNum (index 1)
            firstName: firstName,             // Column C - FNAME (index 2)
            middleInitial: row[3] || '',      // Column D - MI (index 3)
            lastName: lastName,               // Column E - LNAME (index 4)
            address: row[5] || '',            // Column F - ADDRESS (index 5)
            city: row[6] || '',               // Column G - CITY (index 6)
            state: row[7] || 'VA',            // Column H - ST (index 7)
            zip: row[8] || '',                // Column I - ZIP (index 8)
            phone: row[9] || '',              // Column J - PHONE (index 9)
            dob: dob,                         // Column K - DOB (index 10) - CONVERTED
            age: calculateLeagueAge(dob),     // Calculate league age from DOB using 2026 chart
            association: association,         // From cell B3
            league: league,                   // From cell B4
            year: year,                       // From cell B5
            teamName: teamName || '',         // NEW: Head coach's last name
            division: division || '',         // NEW: American/National (for Mustang/Bronco/Pony)
            cbcControl: row[13] || '',        // Column N - CBC_CONTROL (index 13)
            bc: row[14] || '',                // Column O - BC (index 14)
            freeAgent: row[15] || '',         // Column P - FreeAgent (index 15)
            travelPlayer: row[16] || '',      // Column Q - TravelPlayer (index 16)
            notes: row[17] || '',             // Column R - Notes (index 17)
            email: row[18] || '',             // Column S - Email (index 18)
            
            // Auto-set status based on year being uploaded
            // If uploading current/future year rosters → Active
            // If uploading historical rosters (e.g., 2025 in Oct 2025) → Inactive
            status: (() => {
                const currentYear = new Date().getFullYear();
                const uploadYear = parseInt(year);
                return uploadYear >= currentYear ? 'active' : 'inactive';
            })(),
            
            lastPlayedYear: year,             // NEW: Track last year played
            seasons: [{                       // NEW: Track all seasons played
                year: year,
                league: league,
                playerNum: row[0] || '',
                unifNum: row[1] || '',
                age: calculateLeagueAge(dob),  // Calculate league age for season
                teamName: teamName || '',
                division: division || ''
            }],
            addedDate: new Date().toISOString()
        };
        
        players.push(player);
        added++;
    }
    
    return { added, duplicates, coachesAdded };
}

// Generate unique player ID
function generatePlayerId() {
    return 'P' + Date.now() + Math.random().toString(36).substr(2, 9);
}

// Sample data generator for testing
function generateSampleData() {
    const samplePlayers = [
        {
            id: Date.now() + 1,
            playerNum: 1,
            unifNum: 12,
            firstName: "COHEN",
            middleInitial: "DAVID",
            lastName: "CARROLL",
            address: "12101 SLOAN DRIVE",
            city: "CHESTER",
            state: "VA",
            zip: "23836",
            phone: "8047319723",
            dob: "2016-10-13",
            age: 8,
            association: "SCOTT",
            league: "PINTO",
            year: 2025,
            cbcControl: "",
            bc: "",
            freeAgent: "",
            travelPlayer: "",
            notes: "",
            email: "JDC0120@GMAIL.COM"
        },
        {
            id: Date.now() + 2,
            playerNum: 2,
            unifNum: 5,
            firstName: "JAMES",
            middleInitial: "ANTHONY",
            lastName: "SHERRILL",
            address: "2100 BURGESS ROAD",
            city: "CHESTER",
            state: "VA",
            zip: "23836",
            phone: "8043897008",
            dob: "2017-03-10",
            age: 8,
            association: "SCOTT",
            league: "PINTO",
            year: 2025,
            cbcControl: "",
            bc: "",
            freeAgent: "",
            travelPlayer: "",
            notes: "",
            email: "MSHERRILL284@GMAIL.COM"
        }
    ];

    players.push(...samplePlayers);
    saveData();
    displayPlayers(players);
    updateDashboard();
    
    alert('✅ Sample data generated! Check the Player Database tab.');
}

// Add sample data button
setTimeout(() => {
    const importSection = document.querySelector('.import-section');
    const sampleBtn = document.createElement('button');
    sampleBtn.className = 'btn btn-secondary';
    sampleBtn.textContent = '🧪 Generate Sample Data (Testing)';
    sampleBtn.style.marginTop = '20px';
    sampleBtn.onclick = generateSampleData;
    importSection.appendChild(sampleBtn);
}, 100);

// Display functions
function displayPlayers(playersToShow) {
    const tbody = document.getElementById('player-tbody');
    
    if (playersToShow.length === 0) {
        tbody.innerHTML = '<tr><td colspan="11" class="empty-state">No players found.</td></tr>';
        return;
    }

    tbody.innerHTML = playersToShow.map(player => {
        // Default to 'active' if no status (legacy data)
        const playerStatus = player.status || 'active';
        const statusBadge = playerStatus === 'active' 
            ? '<span style="background:#059669;color:white;padding:4px 8px;border-radius:4px;font-size:11px;">ACTIVE</span>'
            : '<span style="background:#9ca3af;color:white;padding:4px 8px;border-radius:4px;font-size:11px;">INACTIVE</span>';
        const seasonsPlayed = player.seasons ? player.seasons.length : 1;
        const teamDisplay = player.teamName ? `${player.league} ${player.teamName}` : player.league;
        
        // CBC Control # display
        const cbcDisplay = player.cbcControl 
            ? `<span style="color:#059669;font-weight:600;">${player.cbcControl}</span>`
            : '<span style="color:#ef4444;">Not Assigned</span>';
        
        // Birth Certificate display
        const bcDisplay = player.bc && player.bc.toLowerCase() !== 'n'
            ? '<span style="color:#059669;font-weight:600;">✓ Yes</span>'
            : '<span style="color:#ef4444;">✗ No</span>';
        
        return `
        <tr style="${playerStatus === 'inactive' ? 'opacity: 0.6;' : ''}">
            <td><strong>${player.firstName} ${player.lastName}</strong></td>
            <td>${player.association}</td>
            <td>${teamDisplay}${player.division ? `<br><small style="color:#6b7280;">${player.division}</small>` : ''}</td>
            <td>${player.age}</td>
            <td>${formatDate(player.dob)}</td>
            <td>${cbcDisplay}</td>
            <td>${bcDisplay}</td>
            <td>${statusBadge}<br><small style="color:#6b7280;">${seasonsPlayed} season${seasonsPlayed > 1 ? 's' : ''}</small></td>
            <td>${formatPhone(player.phone)}</td>
            <td>${player.email}</td>
            <td style="white-space: nowrap;">
                <button class="btn btn-small" onclick="viewPlayer('${player.id}')">View</button>
                <button class="btn btn-small" onclick="editPlayer('${player.id}')" style="background:#f59e0b;">Edit</button>
                <button class="btn btn-small btn-danger" onclick="deletePlayer('${player.id}')">Delete</button>
            </td>
        </tr>
        `;
    }).join('');
}

function displayTeams() {
    const teamsList = document.getElementById('teams-list');
    
    // Group players by association, league, year, AND team name
    const teamGroups = {};
    
    players.forEach(player => {
        const teamName = player.teamName || 'NoCoach';
        const division = player.division || '';
        const key = `${player.association}-${player.league}-${teamName}-${division}-${player.year}`;
        if (!teamGroups[key]) {
            teamGroups[key] = {
                association: player.association,
                league: player.league,
                year: player.year,
                teamName: player.teamName || '',
                division: player.division || '',
                players: []
            };
        }
        teamGroups[key].players.push(player);
    });

    if (Object.keys(teamGroups).length === 0) {
        teamsList.innerHTML = '<p class="empty-state">No teams found. Import rosters to see teams.</p>';
        return;
    }

    teamsList.innerHTML = Object.values(teamGroups).map(team => {
        const teamDisplayName = team.teamName 
            ? `${team.association} ${team.league} ${team.teamName}` 
            : `${team.association} ${team.league}`;
        const divisionBadge = team.division 
            ? `<span style="background:#3b82f6;color:white;padding:4px 8px;border-radius:4px;font-size:11px;margin-left:8px;">${team.division}</span>` 
            : '';
        
        return `
        <div class="team-card">
            <h3>${teamDisplayName}${divisionBadge}</h3>
            <p><strong>Year:</strong> ${team.year}</p>
            <p><strong>Players:</strong> ${team.players.length}</p>
            <button class="btn btn-small btn-primary" onclick="viewTeamRoster('${team.association}', '${team.league}', ${team.year}, '${team.teamName}', '${team.division}')">
                View Roster
            </button>
        </div>
    `;
    }).join('');
}

function displayCoaches(coachesToShow = coaches) {
    const tbody = document.getElementById('coach-tbody');
    
    if (coachesToShow.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="empty-state">No coaches found.</td></tr>';
        return;
    }
    
    tbody.innerHTML = coachesToShow.map(coach => {
        return `
            <tr>
                <td><strong>${coach.firstName} ${coach.lastName}</strong></td>
                <td>${coach.association}</td>
                <td>${coach.league}</td>
                <td>${coach.year}</td>
                <td>${coach.phone || '-'}</td>
                <td>${coach.email || '-'}</td>
                <td>${coach.address || '-'}, ${coach.city || '-'}, ${coach.state || 'VA'} ${coach.zip || ''}</td>
                <td>
                    <button class="btn btn-small btn-danger" onclick="deleteCoach('${coach.id}')">Delete</button>
                </td>
            </tr>
        `;
    }).join('');
}

function filterCoaches() {
    const searchTerm = document.getElementById('coach-search').value.toLowerCase();
    const association = document.getElementById('filter-coach-association').value.toUpperCase();
    const league = document.getElementById('filter-coach-league').value;
    const year = document.getElementById('filter-coach-year').value;
    
    let filtered = coaches;
    
    // Apply filters
    if (searchTerm) {
        filtered = filtered.filter(coach =>
            coach.firstName.toLowerCase().includes(searchTerm) ||
            coach.lastName.toLowerCase().includes(searchTerm) ||
            (coach.email && coach.email.toLowerCase().includes(searchTerm)) ||
            (coach.phone && coach.phone.includes(searchTerm))
        );
    }
    
    if (association) {
        filtered = filtered.filter(coach => coach.association.toUpperCase() === association);
    }
    
    if (league) {
        filtered = filtered.filter(coach => coach.league === league);
    }
    
    if (year) {
        filtered = filtered.filter(coach => String(coach.year) === year);
    }
    
    displayCoaches(filtered);
}

function clearCoachFilters() {
    document.getElementById('coach-search').value = '';
    document.getElementById('filter-coach-association').value = '';
    document.getElementById('filter-coach-league').value = '';
    document.getElementById('filter-coach-year').value = '';
    displayCoaches(coaches);
}

function deleteCoach(coachId) {
    if (!confirm('Are you sure you want to delete this coach?')) return;
    
    const index = coaches.findIndex(c => c.id === coachId);
    if (index > -1) {
        coaches.splice(index, 1);
        saveData();
        filterCoaches();
        updateDashboard();
    }
}

function exportCoaches() {
    if (coaches.length === 0) {
        alert('No coaches to export!');
        return;
    }
    
    const wb = XLSX.utils.book_new();
    const wsData = [
        ['Coach #', 'First Name', 'MI', 'Last Name', 'Association', 'League', 'Year', 'Phone', 'Email', 'Address', 'City', 'State', 'ZIP', 'Notes']
    ];
    
    coaches.forEach(coach => {
        wsData.push([
            coach.coachNum || '',
            coach.firstName,
            coach.middleInitial || '',
            coach.lastName,
            coach.association,
            coach.league,
            coach.year,
            coach.phone || '',
            coach.email || '',
            coach.address || '',
            coach.city || '',
            coach.state || 'VA',
            coach.zip || '',
            coach.notes || ''
        ]);
    });
    
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    XLSX.utils.book_append_sheet(wb, ws, 'Coaches');
    
    const timestamp = new Date().toISOString().split('T')[0];
    XLSX.writeFile(wb, `CBC_Coaches_${timestamp}.xlsx`);
}

function updateDashboard() {
    // Legacy data without status is treated as active
    const activePlayers = players.filter(p => !p.status || p.status === 'active').length;
    const inactivePlayers = players.filter(p => p.status === 'inactive').length;
    
    document.getElementById('total-players').textContent = players.length;
    
    // Add breakdown if element exists
    const playerBreakdown = document.getElementById('player-breakdown');
    if (playerBreakdown) {
        playerBreakdown.innerHTML = `<small style="color:#6b7280;">${activePlayers} active, ${inactivePlayers} inactive</small>`;
    }
    
    const uniqueTeams = new Set(players.filter(p => !p.status || p.status === 'active').map(p => `${p.association}-${p.league}-${p.year}`));
    document.getElementById('total-teams').textContent = uniqueTeams.size;

    // Update coaches count in dashboard (add after total-teams if element exists)
    const coachesElement = document.getElementById('total-coaches');
    if (coachesElement) {
        coachesElement.textContent = coaches.length;
    }

    // Quick Analytics
    const analyticsDiv = document.getElementById('quick-analytics');
    if (analyticsDiv) {
        const missingBC = players.filter(p => (!p.bc || p.bc.toLowerCase() === 'n') && (p.status !== 'inactive')).length;
        const missingCBC = players.filter(p => !p.cbcControl && (p.status !== 'inactive')).length;
        const missingEmail = players.filter(p => !p.email && (p.status !== 'inactive')).length;
        const missingPhone = players.filter(p => !p.phone && (p.status !== 'inactive')).length;
        
        // League breakdown
        const leagueBreakdown = {};
        players.filter(p => p.status !== 'inactive').forEach(p => {
            leagueBreakdown[p.league] = (leagueBreakdown[p.league] || 0) + 1;
        });
        
        // Age distribution
        const ageGroups = {
            '4-6': 0,
            '7-8': 0,
            '9-10': 0,
            '11-12': 0,
            '13-14': 0,
            '15+': 0
        };
        players.filter(p => p.status !== 'inactive' && p.age).forEach(p => {
            if (p.age <= 6) ageGroups['4-6']++;
            else if (p.age <= 8) ageGroups['7-8']++;
            else if (p.age <= 10) ageGroups['9-10']++;
            else if (p.age <= 12) ageGroups['11-12']++;
            else if (p.age <= 14) ageGroups['13-14']++;
            else ageGroups['15+']++;
        });
        
        analyticsDiv.innerHTML = `
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px;">
                <div style="background: white; padding: 20px; border-radius: 8px; border: 2px solid #e5e7eb;">
                    <h3 style="margin: 0 0 15px 0; color: #1f2937; font-size: 1em;">🏆 League Distribution</h3>
                    <div style="display: grid; gap: 8px;">
                        ${Object.entries(leagueBreakdown)
                            .sort((a, b) => b[1] - a[1])
                            .slice(0, 5)
                            .map(([league, count]) => {
                                const percentage = ((count / activePlayers) * 100).toFixed(1);
                                return `
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <span style="color: #6b7280; font-size: 0.9em;">${league}</span>
                                    <div style="display: flex; align-items: center; gap: 10px;">
                                        <div style="background: #e5e7eb; height: 8px; width: 100px; border-radius: 4px; overflow: hidden;">
                                            <div style="background: #3b82f6; height: 100%; width: ${percentage}%;"></div>
                                        </div>
                                        <span style="font-weight: 600; min-width: 40px; text-align: right;">${count}</span>
                                    </div>
                                </div>
                            `}).join('')}
                    </div>
                </div>
                
                <div style="background: white; padding: 20px; border-radius: 8px; border: 2px solid #e5e7eb;">
                    <h3 style="margin: 0 0 15px 0; color: #1f2937; font-size: 1em;">📅 Age Distribution</h3>
                    <div style="display: grid; gap: 8px;">
                        ${Object.entries(ageGroups).map(([range, count]) => {
                            const percentage = activePlayers > 0 ? ((count / activePlayers) * 100).toFixed(1) : 0;
                            return `
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <span style="color: #6b7280; font-size: 0.9em;">Ages ${range}</span>
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <div style="background: #e5e7eb; height: 8px; width: 100px; border-radius: 4px; overflow: hidden;">
                                        <div style="background: #10b981; height: 100%; width: ${percentage}%;"></div>
                                    </div>
                                    <span style="font-weight: 600; min-width: 40px; text-align: right;">${count}</span>
                                </div>
                            </div>
                        `}).join('')}
                    </div>
                </div>
                
                <div style="background: white; padding: 20px; border-radius: 8px; border: 2px solid #e5e7eb;">
                    <h3 style="margin: 0 0 15px 0; color: #1f2937; font-size: 1em;">⚠️ Missing Data</h3>
                    <div style="display: grid; gap: 10px;">
                        <div style="display: flex; justify-content: space-between; padding: 8px; background: ${missingBC > 0 ? '#fef3c7' : '#d1fae5'}; border-radius: 6px;">
                            <span style="font-size: 0.9em;">Birth Certificates</span>
                            <strong style="color: ${missingBC > 0 ? '#92400e' : '#065f46'};">${missingBC} missing</strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 8px; background: ${missingCBC > 0 ? '#fef3c7' : '#d1fae5'}; border-radius: 6px;">
                            <span style="font-size: 0.9em;">CBC Control #</span>
                            <strong style="color: ${missingCBC > 0 ? '#92400e' : '#065f46'};">${missingCBC} missing</strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 8px; background: ${missingEmail > 0 ? '#fef3c7' : '#d1fae5'}; border-radius: 6px;">
                            <span style="font-size: 0.9em;">Email Addresses</span>
                            <strong style="color: ${missingEmail > 0 ? '#92400e' : '#065f46'};">${missingEmail} missing</strong>
                        </div>
                        <div style="display: flex; justify-content: space-between; padding: 8px; background: ${missingPhone > 0 ? '#fef3c7' : '#d1fae5'}; border-radius: 6px;">
                            <span style="font-size: 0.9em;">Phone Numbers</span>
                            <strong style="color: ${missingPhone > 0 ? '#92400e' : '#065f46'};">${missingPhone} missing</strong>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    // Data Alerts
    const alertsDiv = document.getElementById('data-alerts');
    if (alertsDiv) {
        const alerts = [];
        
        // Find duplicate players (same name + DOB + association)
        const duplicates = [];
        players.forEach((p1, i) => {
            players.forEach((p2, j) => {
                if (i < j && 
                    p1.firstName.toLowerCase() === p2.firstName.toLowerCase() &&
                    p1.lastName.toLowerCase() === p2.lastName.toLowerCase() &&
                    p1.dob === p2.dob &&
                    p1.association === p2.association) {
                    duplicates.push(`${p1.firstName} ${p1.lastName} (${p1.association})`);
                }
            });
        });
        
        if (duplicates.length > 0) {
            alerts.push({
                type: 'warning',
                icon: '⚠️',
                message: `${duplicates.length} potential duplicate player${duplicates.length > 1 ? 's' : ''} detected`,
                action: 'View duplicates in Missing Data report'
            });
        }
        
        const missingBC = players.filter(p => (!p.bc || p.bc.toLowerCase() === 'n') && p.status !== 'inactive').length;
        if (missingBC > 10) {
            alerts.push({
                type: 'error',
                icon: '🎂',
                message: `${missingBC} players missing birth certificates`,
                action: 'Run Birth Certificate Tracking report'
            });
        }
        
        const missingCBC = players.filter(p => !p.cbcControl && p.status !== 'inactive').length;
        if (missingCBC > 5) {
            alerts.push({
                type: 'warning',
                icon: '🎫',
                message: `${missingCBC} players missing CBC Control numbers`,
                action: 'Review player database and update'
            });
        }
        
        const lastSave = localStorage.getItem('cbc_last_save');
        if (lastSave) {
            const daysSince = Math.floor((Date.now() - new Date(lastSave)) / (1000 * 60 * 60 * 24));
            if (daysSince >= 7) {
                alerts.push({
                    type: 'info',
                    icon: '💾',
                    message: `Last backup was ${daysSince} day${daysSince > 1 ? 's' : ''} ago`,
                    action: 'Create backup now for safety'
                });
            }
        }
        
        if (alerts.length === 0) {
            alertsDiv.innerHTML = '<p style="text-align: center; color: #10b981; padding: 20px; background: #d1fae5; border-radius: 8px;">✅ All systems operational! No alerts.</p>';
        } else {
            alertsDiv.innerHTML = alerts.map(alert => {
                const colors = {
                    error: { bg: '#fee2e2', border: '#ef4444', text: '#991b1b' },
                    warning: { bg: '#fef3c7', border: '#f59e0b', text: '#92400e' },
                    info: { bg: '#dbeafe', border: '#3b82f6', text: '#1e40af' }
                };
                const color = colors[alert.type];
                return `
                    <div style="background: ${color.bg}; border-left: 4px solid ${color.border}; padding: 15px; margin-bottom: 10px; border-radius: 6px;">
                        <div style="display: flex; align-items: start; gap: 12px;">
                            <span style="font-size: 1.5em;">${alert.icon}</span>
                            <div style="flex: 1;">
                                <div style="font-weight: 600; color: ${color.text}; margin-bottom: 4px;">${alert.message}</div>
                                <div style="font-size: 0.9em; color: ${color.text}; opacity: 0.8;">${alert.action}</div>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
        }
    }

    // Submission status
    const statusDiv = document.getElementById('submission-status');
    const submittedAssociations = new Set(players.map(p => p.association));
    
    const statusHTML = associations.map(assoc => {
        const submitted = submittedAssociations.has(assoc.toUpperCase());
        return `
            <div style="display:flex; justify-content:space-between; padding:10px; border-bottom:1px solid #e5e7eb;">
                <span>${assoc}</span>
                <span style="color:${submitted ? '#059669' : '#9ca3af'}">
                    ${submitted ? '✅ Submitted' : '⏳ Pending'}
                </span>
            </div>
        `;
    }).join('');
    
    statusDiv.innerHTML = statusHTML;
}

// Filter and search functions
function filterPlayers() {
    const searchTerm = document.getElementById('player-search').value.toLowerCase();
    const association = document.getElementById('filter-association').value;
    const league = document.getElementById('filter-league').value;
    const year = document.getElementById('filter-year').value;
    const status = document.getElementById('filter-status').value;

    console.log('Filter values:', { association, league, year, status });
    console.log('Total players:', players.length);
    console.log('Sample player:', players[0]);

    const filtered = players.filter(player => {
        const matchesSearch = !searchTerm || 
            player.firstName.toLowerCase().includes(searchTerm) ||
            player.lastName.toLowerCase().includes(searchTerm) ||
            player.email.toLowerCase().includes(searchTerm);
        
        const matchesAssociation = !association || player.association.toUpperCase() === association.toUpperCase();
        const matchesLeague = !league || player.league.toUpperCase() === league.toUpperCase();
        const matchesYear = !year || player.year === parseInt(year);
        // If no status filter OR player status matches OR player has no status (legacy data treated as active)
        const matchesStatus = !status || player.status === status || (!player.status && status === 'active');

        return matchesSearch && matchesAssociation && matchesLeague && matchesYear && matchesStatus;
    });

    console.log('Filtered players:', filtered.length);
    displayPlayers(filtered);
}

function clearFilters() {
    document.getElementById('player-search').value = '';
    document.getElementById('filter-association').value = '';
    document.getElementById('filter-league').value = '';
    document.getElementById('filter-year').value = '';
    document.getElementById('filter-status').value = 'active';
    filterPlayers();
}

function populateFilters() {
    // Populate association filter for players
    const assocFilter = document.getElementById('filter-association');
    associations.forEach(assoc => {
        const option = document.createElement('option');
        option.value = assoc.toUpperCase();
        option.textContent = assoc;
        assocFilter.appendChild(option);
    });

    // Populate year filter for players
    const yearFilter = document.getElementById('filter-year');
    const uniqueYears = [...new Set(players.map(p => p.year))].sort().reverse();
    uniqueYears.forEach(year => {
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year;
        yearFilter.appendChild(option);
    });
    
    // Populate coach filters
    const coachAssocFilter = document.getElementById('filter-coach-association');
    associations.forEach(assoc => {
        const option = document.createElement('option');
        option.value = assoc.toUpperCase();
        option.textContent = assoc;
        coachAssocFilter.appendChild(option);
    });
    
    const coachYearFilter = document.getElementById('filter-coach-year');
    const coachUniqueYears = [...new Set(coaches.map(c => c.year))].sort().reverse();
    coachUniqueYears.forEach(year => {
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year;
        coachYearFilter.appendChild(option);
    });
}

// Utility functions
function formatDate(dateStr) {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US');
}

function formatPhone(phone) {
    if (!phone) return '';
    const cleaned = String(phone).replace(/\D/g, '');
    const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
        return '(' + match[1] + ') ' + match[2] + '-' + match[3];
    }
    return phone;
}

// Data persistence
function saveData() {
    localStorage.setItem('cbc_players', JSON.stringify(players));
    localStorage.setItem('cbc_coaches', JSON.stringify(coaches));
    localStorage.setItem('cbc_teams', JSON.stringify(teams));
    localStorage.setItem('cbc_documents', JSON.stringify(documents));
    localStorage.setItem('cbc_last_save', new Date().toISOString());
}

function loadData() {
    const savedPlayers = localStorage.getItem('cbc_players');
    const savedCoaches = localStorage.getItem('cbc_coaches');
    const savedTeams = localStorage.getItem('cbc_teams');
    const savedDocs = localStorage.getItem('cbc_documents');
    
    if (savedPlayers) {
        players = JSON.parse(savedPlayers);
    }
    if (savedCoaches) {
        coaches = JSON.parse(savedCoaches);
    }
    if (savedTeams) {
        teams = JSON.parse(savedTeams);
    }
    if (savedDocs) {
        documents = JSON.parse(savedDocs);
    }
}

// ============================================================================
// BACKUP & RESTORE - For Thumb Drive / File-Based Storage
// ============================================================================

function downloadBackup() {
    const backup = {
        version: '2.2',
        exportDate: new Date().toISOString(),
        playerCount: players.length,
        coachCount: coaches.length,
        teamCount: teams.length,
        documentCount: documents.length,
        data: {
            players: players,
            coaches: coaches,
            teams: teams,
            documents: documents
        }
    };
    
    const json = JSON.stringify(backup, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cbc-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    
    alert(`✅ Backup saved!\n\nPlayers: ${players.length}\nCoaches: ${coaches.length}\nTeams: ${teams.length}\nDocuments: ${documents.length}\n\nSave this file to your thumb drive!`);
}

function uploadBackup(file) {
    const reader = new FileReader();
    reader.onload = (e) => {
        try {
            const backup = JSON.parse(e.target.result);
            
            if (!backup.data || !backup.version) {
                alert('❌ Invalid backup file format!');
                return;
            }
            
            // Confirm restore
            const confirmed = confirm(
                `📥 RESTORE BACKUP?\n\n` +
                `Backup Date: ${new Date(backup.exportDate).toLocaleDateString()}\n` +
                `Players: ${backup.playerCount}\n` +
                `Coaches: ${backup.coachCount}\n` +
                `Teams: ${backup.teamCount}\n` +
                `Documents: ${backup.documentCount}\n\n` +
                `⚠️ This will REPLACE all current data!\n\n` +
                `Click OK to restore, Cancel to abort.`
            );
            
            if (!confirmed) return;
            
            // Restore data
            players = backup.data.players || [];
            coaches = backup.data.coaches || [];
            teams = backup.data.teams || [];
            documents = backup.data.documents || [];
            
            // Save to localStorage
            saveData();
            
            // Refresh all displays
            updateDashboard();
            displayPlayers(players);
            displayCoaches(coaches);
            displayTeams();
            displayDocuments();
            populateFilters();
            
            alert(`✅ Backup restored successfully!\n\nPlayers: ${players.length}\nCoaches: ${coaches.length}\nTeams: ${teams.length}\nDocuments: ${documents.length}`);
            
        } catch (error) {
            alert(`❌ Error reading backup file: ${error.message}`);
        }
    };
    reader.readAsText(file);
}

function showBackupRestore() {
    const modal = document.createElement('div');
    modal.id = 'backup-modal';
    modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); display: flex; align-items: center; justify-content: center; z-index: 1000;';
    
    const lastSave = localStorage.getItem('cbc_last_save');
    const lastSaveText = lastSave ? new Date(lastSave).toLocaleString() : 'Never';
    
    modal.innerHTML = `
        <div style="background: white; border-radius: 12px; max-width: 600px; width: 90%; padding: 30px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
            <h2 style="margin: 0 0 20px 0; color: #1f2937;">💾 Backup & Restore</h2>
            
            <div style="background: #f3f4f6; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                <p style="margin: 0 0 10px 0;"><strong>Current Database:</strong></p>
                <p style="margin: 5px 0;">📊 Players: ${players.length}</p>
                <p style="margin: 5px 0;">👨‍🏫 Coaches: ${coaches.length}</p>
                <p style="margin: 5px 0;">⚾ Teams: ${teams.length}</p>
                <p style="margin: 5px 0;">📄 Documents: ${documents.length}</p>
                <p style="margin: 5px 0; color: #6b7280; font-size: 0.9em;">Last saved: ${lastSaveText}</p>
            </div>
            
            <div style="margin-bottom: 20px;">
                <h3 style="margin: 0 0 10px 0; font-size: 1.1em;">📥 Download Backup</h3>
                <p style="margin: 0 0 10px 0; color: #6b7280;">Save all data to a JSON file. Perfect for:</p>
                <ul style="margin: 0 0 15px 0; color: #6b7280; padding-left: 20px;">
                    <li>Storing on a thumb drive</li>
                    <li>Moving to another computer</li>
                    <li>Creating backups before major changes</li>
                    <li>Switching browsers</li>
                </ul>
                <button onclick="downloadBackup(); closeBackupModal();" style="background: #3b82f6; color: white; border: none; padding: 12px 24px; border-radius: 6px; cursor: pointer; font-weight: 500; width: 100%;">
                    💾 Download Backup File
                </button>
            </div>
            
            <div style="margin-bottom: 20px;">
                <h3 style="margin: 0 0 10px 0; font-size: 1.1em;">📤 Restore from Backup</h3>
                <p style="margin: 0 0 10px 0; color: #6b7280;">Upload a previously saved backup file:</p>
                <input type="file" id="backup-file-input" accept=".json" style="margin-bottom: 10px; width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                <button onclick="handleBackupRestore()" style="background: #10b981; color: white; border: none; padding: 12px 24px; border-radius: 6px; cursor: pointer; font-weight: 500; width: 100%;">
                    📤 Restore Backup
                </button>
            </div>
            
            <div style="background: #fef3c7; border: 1px solid #fbbf24; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                <p style="margin: 0; color: #92400e; font-size: 0.9em;">
                    <strong>⚠️ Important:</strong> Restoring a backup will REPLACE all current data. Make sure to download a backup first if you want to keep your current data!
                </p>
            </div>
            
            <button onclick="closeBackupModal()" style="background: #6b7280; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; width: 100%;">
                Close
            </button>
        </div>
    `;
    
    document.body.appendChild(modal);
}

function closeBackupModal() {
    const modal = document.getElementById('backup-modal');
    if (modal) modal.remove();
}

function handleBackupRestore() {
    const fileInput = document.getElementById('backup-file-input');
    if (fileInput.files.length === 0) {
        alert('Please select a backup file first!');
        return;
    }
    uploadBackup(fileInput.files[0]);
    closeBackupModal();
}

// Export functions

// Export all players to Excel
function exportPlayers() {
    if (players.length === 0) {
        alert('No players to export. Import rosters or generate sample data first.');
        return;
    }

    const wb = XLSX.utils.book_new();
    
    // Prepare data for export
    const exportData = players.map(p => ({
        'Player #': p.playerNum,
        'Uniform #': p.unifNum,
        'First Name': p.firstName,
        'MI': p.middleInitial,
        'Last Name': p.lastName,
        'Address': p.address,
        'City': p.city,
        'State': p.state,
        'ZIP': p.zip,
        'Phone': p.phone,
        'Date of Birth': p.dob,
        'Age': p.age,
        'Association': p.association,
        'League': p.league,
        'Year': p.year,
        'CBC Control #': p.cbcControl,
        'Birth Cert': p.bc,
        'Free Agent': p.freeAgent,
        'Travel Player': p.travelPlayer,
        'Notes': p.notes,
        'Email': p.email
    }));
    
    const ws = XLSX.utils.json_to_sheet(exportData);
    
    // Set column widths
    const colWidths = [
        {wch: 10}, {wch: 10}, {wch: 15}, {wch: 5}, {wch: 15},
        {wch: 25}, {wch: 15}, {wch: 5}, {wch: 10}, {wch: 15},
        {wch: 12}, {wch: 5}, {wch: 15}, {wch: 10}, {wch: 6},
        {wch: 12}, {wch: 10}, {wch: 10}, {wch: 12}, {wch: 30}, {wch: 25}
    ];
    ws['!cols'] = colWidths;
    
    XLSX.utils.book_append_sheet(wb, ws, 'All Players');
    
    const fileName = `CBC_All_Players_${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(wb, fileName);
}

// Generate master roster report
function generateMasterRoster() {
    if (players.length === 0) {
        alert('No players in database. Import rosters or generate sample data first.');
        return;
    }

    const wb = XLSX.utils.book_new();
    
    // Group by association
    associations.forEach(assoc => {
        const assocPlayers = players.filter(p => 
            p.association.toUpperCase() === assoc.toUpperCase()
        );
        
        if (assocPlayers.length > 0) {
            const exportData = assocPlayers.map(p => ({
                'Uniform #': p.unifNum,
                'Player Name': `${p.firstName} ${p.lastName}`,
                'DOB': p.dob,
                'Age': p.age,
                'League': p.league,
                'Phone': p.phone,
                'Email': p.email,
                'Address': `${p.address}, ${p.city}, ${p.state} ${p.zip}`,
                'BC': p.bc,
                'Year': p.year
            }));
            
            const ws = XLSX.utils.json_to_sheet(exportData);
            ws['!cols'] = [
                {wch: 10}, {wch: 20}, {wch: 12}, {wch: 5}, {wch: 10},
                {wch: 15}, {wch: 25}, {wch: 35}, {wch: 5}, {wch: 6}
            ];
            
            // Truncate sheet name to 31 chars (Excel limit)
            const sheetName = assoc.substring(0, 31);
            XLSX.utils.book_append_sheet(wb, ws, sheetName);
        }
    });
    
    const fileName = `CBC_Master_Roster_${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(wb, fileName);
}

// Generate association summary report
function generateAssociationReport() {
    if (players.length === 0) {
        alert('No players in database. Import rosters or generate sample data first.');
        return;
    }

    const wb = XLSX.utils.book_new();
    
    const summaryData = associations.map(assoc => {
        const assocPlayers = players.filter(p => 
            p.association.toUpperCase() === assoc.toUpperCase()
        );
        
        const leagues = [...new Set(assocPlayers.map(p => p.league))];
        
        return {
            'Association': assoc,
            'Total Players': assocPlayers.length,
            'Leagues': leagues.join(', '),
            'Teams': leagues.length,
            'Players with BC': assocPlayers.filter(p => p.bc).length,
            'Missing BC': assocPlayers.filter(p => !p.bc).length,
            'Travel Players': assocPlayers.filter(p => p.travelPlayer).length,
            'Free Agents': assocPlayers.filter(p => p.freeAgent).length
        };
    }).filter(row => row['Total Players'] > 0);
    
    const ws = XLSX.utils.json_to_sheet(summaryData);
    ws['!cols'] = [
        {wch: 20}, {wch: 15}, {wch: 30}, {wch: 8},
        {wch: 15}, {wch: 12}, {wch: 15}, {wch: 12}
    ];
    
    XLSX.utils.book_append_sheet(wb, ws, 'Summary');
    
    const fileName = `CBC_Association_Summary_${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(wb, fileName);
}

// Generate age group report
function generateAgeGroupReport() {
    if (players.length === 0) {
        alert('No players in database. Import rosters or generate sample data first.');
        return;
    }

    const wb = XLSX.utils.book_new();
    
    const leagues = [...new Set(players.map(p => p.league))].sort();
    
    leagues.forEach(league => {
        const leaguePlayers = players.filter(p => p.league === league);
        
        const exportData = leaguePlayers.map(p => ({
            'Association': p.association,
            'Uniform #': p.unifNum,
            'Player Name': `${p.firstName} ${p.lastName}`,
            'DOB': p.dob,
            'Age': p.age,
            'Phone': p.phone,
            'Email': p.email,
            'BC': p.bc
        }));
        
        const ws = XLSX.utils.json_to_sheet(exportData);
        ws['!cols'] = [
            {wch: 15}, {wch: 10}, {wch: 20}, {wch: 12},
            {wch: 5}, {wch: 15}, {wch: 25}, {wch: 5}
        ];
        
        const sheetName = league.substring(0, 31);
        XLSX.utils.book_append_sheet(wb, ws, sheetName);
    });
    
    const fileName = `CBC_Age_Groups_${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(wb, fileName);
}

// Generate missing data report
function generateMissingDataReport() {
    if (players.length === 0) {
        alert('No players in database. Import rosters or generate sample data first.');
        return;
    }

    const missingPlayers = players.filter(p => 
        !p.bc || !p.dob || !p.phone || !p.email || !p.address
    );
    
    if (missingPlayers.length === 0) {
        alert('Great! All players have complete data.');
        return;
    }

    const wb = XLSX.utils.book_new();
    
    const exportData = missingPlayers.map(p => ({
        'Association': p.association,
        'League': p.league,
        'Player Name': `${p.firstName} ${p.lastName}`,
        'Missing BC': p.bc ? '' : 'YES',
        'Missing DOB': p.dob ? '' : 'YES',
        'Missing Phone': p.phone ? '' : 'YES',
        'Missing Email': p.email ? '' : 'YES',
        'Missing Address': p.address ? '' : 'YES',
        'Notes': p.notes
    }));
    
    const ws = XLSX.utils.json_to_sheet(exportData);
    ws['!cols'] = [
        {wch: 15}, {wch: 10}, {wch: 20}, {wch: 12},
        {wch: 12}, {wch: 15}, {wch: 15}, {wch: 18}, {wch: 30}
    ];
    
    XLSX.utils.book_append_sheet(wb, ws, 'Missing Data');
    
    const fileName = `CBC_Missing_Data_${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(wb, fileName);
    
    alert(`Found ${missingPlayers.length} players with incomplete data. Report downloaded.`);
}


function generateMasterReport() {
    alert('Report generation coming in Phase 2');
}

function generateAssociationReport() {
    alert('Report generation coming in Phase 2');
}

function generateAgeReport() {
    alert('Report generation coming in Phase 2');
}

function generateMissingDataReport() {
    if (players.length === 0) {
        alert('No players in database. Import rosters or generate sample data first.');
        return;
    }

    const wb = XLSX.utils.book_new();
    
    // Check each player for missing critical data
    const incompleteData = [];
    
    players.forEach(player => {
        const issues = [];
        
        // Critical fields to check
        if (!player.dob || player.dob === '') issues.push('Missing DOB');
        if (!player.phone || player.phone === '') issues.push('Missing Phone');
        if (!player.email || player.email === '') issues.push('Missing Email');
        if (!player.address || player.address === '') issues.push('Missing Address');
        if (!player.city || player.city === '') issues.push('Missing City');
        if (!player.zip || player.zip === '') issues.push('Missing ZIP');
        if (!player.bc || player.bc === '' || player.bc === 'N') issues.push('Missing Birth Certificate');
        if (!player.cbcControl || player.cbcControl === '') issues.push('Missing CBC Control #');
        
        // Add to report if any issues found
        if (issues.length > 0) {
            incompleteData.push({
                'Association': player.association,
                'Team': player.teamName ? `${player.league} ${player.teamName}` : player.league,
                'Player #': player.playerNum,
                'Player Name': `${player.firstName} ${player.lastName}`,
                'Age': player.age,
                'Year': player.year,
                'Missing Fields': issues.join(', '),
                'Issue Count': issues.length
            });
        }
    });
    
    if (incompleteData.length === 0) {
        alert('✅ Great! All players have complete information!');
        return;
    }
    
    // Sort by association, then by issue count (most issues first)
    incompleteData.sort((a, b) => {
        if (a.Association !== b.Association) {
            return a.Association.localeCompare(b.Association);
        }
        return b['Issue Count'] - a['Issue Count'];
    });
    
    // Create worksheet
    const ws = XLSX.utils.json_to_sheet(incompleteData);
    ws['!cols'] = [
        {wch: 15}, // Association
        {wch: 20}, // Team
        {wch: 10}, // Player #
        {wch: 25}, // Player Name
        {wch: 5},  // Age
        {wch: 6},  // Year
        {wch: 60}, // Missing Fields
        {wch: 8}   // Issue Count
    ];
    
    XLSX.utils.book_append_sheet(wb, ws, 'Incomplete Players');
    
    // Summary sheet
    const summaryData = associations.map(assoc => {
        const assocPlayers = incompleteData.filter(p => p.Association.toUpperCase() === assoc.toUpperCase());
        const totalPlayers = players.filter(p => p.association.toUpperCase() === assoc.toUpperCase()).length;
        const incompleteCount = assocPlayers.length;
        const completeCount = totalPlayers - incompleteCount;
        const completionRate = totalPlayers > 0 ? ((completeCount / totalPlayers) * 100).toFixed(1) : '0.0';
        
        return {
            'Association': assoc,
            'Total Players': totalPlayers,
            'Complete': completeCount,
            'Incomplete': incompleteCount,
            'Completion %': completionRate
        };
    }).filter(s => s['Total Players'] > 0);
    
    const wsSummary = XLSX.utils.json_to_sheet(summaryData);
    wsSummary['!cols'] = [{wch: 15}, {wch: 12}, {wch: 10}, {wch: 12}, {wch: 12}];
    XLSX.utils.book_append_sheet(wb, wsSummary, 'Summary');
    
    const fileName = `CBC_Missing_Data_Report_${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(wb, fileName);
    
    alert(`📊 Missing Data Report Generated!\n\n${incompleteData.length} players with incomplete information.\n\nCheck the Excel file for details.`);
}

// Generate Team Rosters Report (one sheet per team)
function generateTeamRostersReport() {
    if (players.length === 0) {
        alert('No players in database. Import rosters or generate sample data first.');
        return;
    }

    const wb = XLSX.utils.book_new();
    
    // Group players by team
    const teams = {};
    players.forEach(player => {
        const teamName = player.teamName || 'NoCoach';
        const division = player.division || '';
        const teamKey = `${player.association}_${player.league}_${teamName}_${division}_${player.year}`;
        
        if (!teams[teamKey]) {
            teams[teamKey] = {
                association: player.association,
                league: player.league,
                teamName: player.teamName || '',
                division: player.division || '',
                year: player.year,
                players: []
            };
        }
        teams[teamKey].players.push(player);
    });
    
    // Create a sheet for each team
    Object.values(teams).forEach(team => {
        const teamDisplayName = team.teamName 
            ? `${team.association} ${team.league} ${team.teamName}` 
            : `${team.association} ${team.league}`;
        
        const exportData = team.players.map(p => ({
            'Uniform #': p.unifNum || '',
            'Player #': p.playerNum || '',
            'First Name': p.firstName,
            'Last Name': p.lastName,
            'DOB': formatDate(p.dob),
            'Age': p.age,
            'Phone': formatPhone(p.phone),
            'Email': p.email || '',
            'Address': p.address || '',
            'City': p.city || '',
            'State': p.state || 'VA',
            'ZIP': p.zip || '',
            'BC': p.bc || ''
        }));
        
        const ws = XLSX.utils.json_to_sheet(exportData);
        ws['!cols'] = [
            {wch: 10}, {wch: 10}, {wch: 15}, {wch: 15}, {wch: 12},
            {wch: 5}, {wch: 15}, {wch: 25}, {wch: 25}, {wch: 15},
            {wch: 5}, {wch: 10}, {wch: 5}
        ];
        
        // Create sheet name (Excel limit 31 chars)
        let sheetName = teamDisplayName;
        if (team.division) sheetName += ` ${team.division}`;
        sheetName = sheetName.substring(0, 31);
        
        XLSX.utils.book_append_sheet(wb, ws, sheetName);
    });
    
    const fileName = `CBC_Team_Rosters_${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(wb, fileName);
    alert(`✅ Team Rosters Report Generated!\n\n${Object.keys(teams).length} teams exported.`);
}

// Generate Birth Certificate Tracking Report
function generateBirthCertReport() {
    if (players.length === 0) {
        alert('No players in database. Import rosters or generate sample data first.');
        return;
    }

    const wb = XLSX.utils.book_new();
    
    // Players missing birth certificates
    const missingBC = players.filter(p => !p.bc || p.bc === '' || p.bc === 'N' || p.bc.toUpperCase() === 'NO');
    const hasBC = players.filter(p => p.bc && p.bc !== '' && p.bc !== 'N' && p.bc.toUpperCase() !== 'NO');
    
    // Missing BC sheet
    if (missingBC.length > 0) {
        const missingData = missingBC.map(p => ({
            'Association': p.association,
            'Team': p.teamName ? `${p.league} ${p.teamName}` : p.league,
            'Player Name': `${p.firstName} ${p.lastName}`,
            'DOB': formatDate(p.dob),
            'Age': p.age,
            'Phone': formatPhone(p.phone),
            'Email': p.email || '',
            'Year': p.year
        }));
        
        const ws = XLSX.utils.json_to_sheet(missingData);
        ws['!cols'] = [{wch: 15}, {wch: 20}, {wch: 25}, {wch: 12}, {wch: 5}, {wch: 15}, {wch: 25}, {wch: 6}];
        XLSX.utils.book_append_sheet(wb, ws, 'Missing Birth Certs');
    }
    
    // Has BC sheet
    if (hasBC.length > 0) {
        const hasData = hasBC.map(p => ({
            'Association': p.association,
            'Team': p.teamName ? `${p.league} ${p.teamName}` : p.league,
            'Player Name': `${p.firstName} ${p.lastName}`,
            'DOB': formatDate(p.dob),
            'BC Status': p.bc,
            'Year': p.year
        }));
        
        const ws = XLSX.utils.json_to_sheet(hasData);
        ws['!cols'] = [{wch: 15}, {wch: 20}, {wch: 25}, {wch: 12}, {wch: 15}, {wch: 6}];
        XLSX.utils.book_append_sheet(wb, ws, 'Has Birth Certs');
    }
    
    // Summary by association
    const summaryData = associations.map(assoc => {
        const assocPlayers = players.filter(p => p.association.toUpperCase() === assoc.toUpperCase());
        const missing = assocPlayers.filter(p => !p.bc || p.bc === '' || p.bc === 'N' || p.bc.toUpperCase() === 'NO').length;
        const complete = assocPlayers.length - missing;
        const rate = assocPlayers.length > 0 ? ((complete / assocPlayers.length) * 100).toFixed(1) : '0.0';
        
        return {
            'Association': assoc,
            'Total Players': assocPlayers.length,
            'Has BC': complete,
            'Missing BC': missing,
            'Completion %': rate
        };
    }).filter(s => s['Total Players'] > 0);
    
    const wsSummary = XLSX.utils.json_to_sheet(summaryData);
    wsSummary['!cols'] = [{wch: 15}, {wch: 12}, {wch: 10}, {wch: 12}, {wch: 12}];
    XLSX.utils.book_append_sheet(wb, wsSummary, 'BC Summary');
    
    const fileName = `CBC_Birth_Certificate_Report_${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(wb, fileName);
    
    const totalRate = players.length > 0 ? ((hasBC.length / players.length) * 100).toFixed(1) : '0';
    alert(`📋 Birth Certificate Report Generated!\n\n✅ ${hasBC.length} players with BC\n❌ ${missingBC.length} players missing BC\n📊 ${totalRate}% completion rate`);
}

// Generate Contact List Report
function generateContactReport() {
    if (players.length === 0) {
        alert('No players in database. Import rosters or generate sample data first.');
        return;
    }

    const wb = XLSX.utils.book_new();
    
    const contactData = players.map(p => ({
        'Association': p.association,
        'Team': p.teamName ? `${p.league} ${p.teamName}` : p.league,
        'Division': p.division || '',
        'Player Name': `${p.firstName} ${p.lastName}`,
        'Phone': formatPhone(p.phone),
        'Email': p.email || '',
        'Address': p.address || '',
        'City': p.city || '',
        'State': p.state || 'VA',
        'ZIP': p.zip || '',
        'Year': p.year
    }));
    
    // Sort by association, then team
    contactData.sort((a, b) => {
        if (a.Association !== b.Association) return a.Association.localeCompare(b.Association);
        return a.Team.localeCompare(b.Team);
    });
    
    const ws = XLSX.utils.json_to_sheet(contactData);
    ws['!cols'] = [
        {wch: 15}, {wch: 20}, {wch: 12}, {wch: 25}, {wch: 15},
        {wch: 30}, {wch: 25}, {wch: 15}, {wch: 5}, {wch: 10}, {wch: 6}
    ];
    
    XLSX.utils.book_append_sheet(wb, ws, 'Contact List');
    
    const fileName = `CBC_Contact_List_${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(wb, fileName);
    alert(`📞 Contact List Generated!\n\n${contactData.length} player contacts exported.`);
}

function viewPlayer(id) {
    const player = players.find(p => p.id === id);
    if (!player) return;
    
    // Find documents linked to this player
    const playerDocs = documents.filter(d => d.playerId === id);
    
    // Create modal HTML
    const modalHTML = `
        <div id="player-modal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); display: flex; align-items: center; justify-content: center; z-index: 1000;">
            <div style="background: white; border-radius: 12px; max-width: 800px; max-height: 90vh; overflow-y: auto; padding: 30px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 20px;">
                    <h2 style="margin: 0; color: #1f2937;">👤 ${player.firstName} ${player.lastName}</h2>
                    <div style="display: flex; gap: 10px;">
                        <button onclick="printPlayerCard('${player.id}')" style="background: #3b82f6; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: 500;">🖨️ Print</button>
                        <button onclick="closePlayerModal()" style="background: #ef4444; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; font-size: 16px;">✕ Close</button>
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 25px;">
                    <div>
                        <h3 style="color: #6366f1; margin-bottom: 10px; font-size: 1.1rem;">📋 Basic Information</h3>
                        <p><strong>Player #:</strong> ${player.playerNum || 'N/A'}</p>
                        <p><strong>Uniform #:</strong> ${player.unifNum || 'N/A'}</p>
                        <p><strong>Middle Initial:</strong> ${player.middleInitial || 'N/A'}</p>
                        <p><strong>Date of Birth:</strong> ${formatDate(player.dob) || 'N/A'}</p>
                        <p><strong>Age:</strong> ${player.age || 'N/A'}</p>
                    </div>
                    
                    <div>
                        <h3 style="color: #6366f1; margin-bottom: 10px; font-size: 1.1rem;">🏆 Team Information</h3>
                        <p><strong>Association:</strong> ${player.association}</p>
                        <p><strong>League:</strong> ${player.league}</p>
                        <p><strong>Year:</strong> ${player.year}</p>
                        <p><strong>CBC Control #:</strong> ${player.cbcControl || 'N/A'}</p>
                        <p><strong>Birth Cert:</strong> ${player.bc || 'N/A'}</p>
                    </div>
                </div>
                
                <div style="margin-bottom: 25px;">
                    <h3 style="color: #6366f1; margin-bottom: 10px; font-size: 1.1rem;">📍 Contact Information</h3>
                    <p><strong>Address:</strong> ${player.address || 'N/A'}</p>
                    <p><strong>City:</strong> ${player.city || 'N/A'}, <strong>State:</strong> ${player.state || 'N/A'}, <strong>ZIP:</strong> ${player.zip || 'N/A'}</p>
                    <p><strong>Phone:</strong> ${formatPhone(player.phone) || 'N/A'}</p>
                    <p><strong>Email:</strong> ${player.email || 'N/A'}</p>
                </div>
                
                <div style="margin-bottom: 25px;">
                    <h3 style="color: #6366f1; margin-bottom: 10px; font-size: 1.1rem;">⚾ Player Status</h3>
                    <p><strong>Status:</strong> ${player.status === 'active' ? '<span style="color:#059669;">✅ ACTIVE</span>' : '<span style="color:#9ca3af;">⏸️ INACTIVE</span>'}</p>
                    <p><strong>Last Played Year:</strong> ${player.lastPlayedYear || player.year}</p>
                    <p><strong>Free Agent:</strong> ${player.freeAgent || 'No'}</p>
                    <p><strong>Travel Player:</strong> ${player.travelPlayer || 'No'}</p>
                    <p><strong>Notes:</strong> ${player.notes || 'None'}</p>
                </div>
                
                ${player.seasons && player.seasons.length > 0 ? `
                <div style="margin-bottom: 25px;">
                    <h3 style="color: #6366f1; margin-bottom: 10px; font-size: 1.1rem;">📅 Season History (${player.seasons.length} season${player.seasons.length > 1 ? 's' : ''})</h3>
                    <div style="display: grid; gap: 8px;">
                        ${player.seasons.map(season => {
                            const teamInfo = season.teamName ? ` - ${season.league} ${season.teamName}` : ` - ${season.league}`;
                            const divInfo = season.division ? ` (${season.division})` : '';
                            return `
                            <div style="background: #f3f4f6; padding: 10px; border-radius: 6px;">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <span><strong>${season.year}</strong>${teamInfo}${divInfo}</span>
                                    <span style="color: #6b7280;">Age ${season.age} | #${season.playerNum || 'N/A'}</span>
                                </div>
                            </div>
                        `}).join('')}
                    </div>
                </div>
                ` : ''}
                
                <div>
                    <h3 style="color: #6366f1; margin-bottom: 10px; font-size: 1.1rem;">📄 Documents (${playerDocs.length})</h3>
                    ${playerDocs.length > 0 ? `
                        <div style="display: grid; gap: 10px;">
                            ${playerDocs.map(doc => `
                                <div style="background: #f3f4f6; padding: 12px; border-radius: 6px; display: flex; justify-content: space-between; align-items: center;">
                                    <div>
                                        <strong>${doc.name}</strong>
                                        <small style="display: block; color: #6b7280;">${doc.type === 'birth-cert' ? '🎂 Birth Certificate' : doc.type === 'waiver' ? '📝 Waiver' : doc.type === 'registration' ? '📋 Registration' : '📄 Other'}</small>
                                    </div>
                                    <button onclick="viewDocument('${doc.id}')" style="background: #3b82f6; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer;">View</button>
                                </div>
                            `).join('')}
                        </div>
                    ` : '<p style="color: #6b7280; font-style: italic;">No documents uploaded for this player</p>'}
                </div>
                
                <div style="margin-top: 25px; padding-top: 20px; border-top: 2px solid #e5e7eb; display: flex; gap: 10px; justify-content: flex-end;">
                    <button onclick="deletePlayer('${player.id}')" style="background: #ef4444; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 500;">🗑️ Delete Player</button>
                    <button onclick="closePlayerModal()" style="background: #6b7280; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 500;">Close</button>
                </div>
            </div>
        </div>
    `;
    
    // Add modal to page
    document.body.insertAdjacentHTML('beforeend', modalHTML);
}

function closePlayerModal() {
    const modal = document.getElementById('player-modal');
    if (modal) {
        modal.remove();
    }
}

function deletePlayer(id) {
    const player = players.find(p => p.id === id);
    if (!player) return;
    
    if (confirm(`Are you sure you want to delete ${player.firstName} ${player.lastName}?\n\nThis action cannot be undone.`)) {
        // Remove player
        players = players.filter(p => p.id !== id);
        
        // Also delete any documents linked to this player
        documents = documents.filter(d => d.playerId !== id);
        
        // Save and refresh
        saveData();
        updateDashboard();
        displayPlayers(players);
        
        // Close modal if open
        closePlayerModal();
        
        alert(`✅ ${player.firstName} ${player.lastName} has been deleted.`);
    }
}

function viewTeamRoster(association, league, year, teamName = '', division = '') {
    const teamPlayers = players.filter(p => {
        const matchesBasic = p.association === association && 
                            p.league === league && 
                            p.year === year;
        
        if (teamName && division) {
            return matchesBasic && p.teamName === teamName && p.division === division;
        } else if (teamName) {
            return matchesBasic && p.teamName === teamName;
        }
        return matchesBasic;
    });
    
    const teamCoaches = coaches.filter(c => 
        c.association === association && 
        c.league === league && 
        c.year === year
    );
    
    // Calculate stats
    const avgAge = teamPlayers.length > 0 
        ? (teamPlayers.reduce((sum, p) => sum + (p.age || 0), 0) / teamPlayers.length).toFixed(1)
        : 0;
    const withBC = teamPlayers.filter(p => p.bc && p.bc.toLowerCase() !== 'n').length;
    const withEmail = teamPlayers.filter(p => p.email).length;
    
    const teamFullName = teamName && division 
        ? `${association} ${league} ${division} - ${teamName}`
        : teamName 
            ? `${association} ${league} - ${teamName}`
            : `${association} ${league}`;
    
    const modal = document.createElement('div');
    modal.id = 'team-roster-modal';
    modal.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); display: flex; align-items: center; justify-content: center; z-index: 2000; overflow-y: auto; padding: 20px;';
    
    modal.innerHTML = `
        <div style="background: white; border-radius: 16px; max-width: 1200px; width: 100%; max-height: 90vh; overflow-y: auto; box-shadow: 0 20px 60px rgba(0,0,0,0.4);">
            <!-- Header -->
            <div style="background: linear-gradient(135deg, #3b82f6 0%, #1e40af 100%); color: white; padding: 30px; border-radius: 16px 16px 0 0; position: sticky; top: 0; z-index: 10;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h2 style="margin: 0 0 10px 0; font-size: 2em;">⚾ ${teamFullName}</h2>
                        <p style="margin: 0; opacity: 0.9; font-size: 1.1em;">${year} Season Roster</p>
                    </div>
                    <button onclick="closeTeamRosterModal()" style="background: rgba(255,255,255,0.2); border: 2px solid white; color: white; width: 40px; height: 40px; border-radius: 50%; cursor: pointer; font-size: 1.5em; line-height: 1;">×</button>
                </div>
            </div>
            
            <!-- Quick Stats -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; padding: 20px; background: #f9fafb; border-bottom: 1px solid #e5e7eb;">
                <div style="text-align: center; padding: 15px; background: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                    <div style="font-size: 2em; font-weight: bold; color: #3b82f6;">${teamPlayers.length}</div>
                    <div style="color: #6b7280; font-size: 0.9em; margin-top: 5px;">Players</div>
                </div>
                <div style="text-align: center; padding: 15px; background: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                    <div style="font-size: 2em; font-weight: bold; color: #10b981;">${teamCoaches.length}</div>
                    <div style="color: #6b7280; font-size: 0.9em; margin-top: 5px;">Coaches</div>
                </div>
                <div style="text-align: center; padding: 15px; background: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                    <div style="font-size: 2em; font-weight: bold; color: #f59e0b;">${avgAge}</div>
                    <div style="color: #6b7280; font-size: 0.9em; margin-top: 5px;">Avg Age</div>
                </div>
                <div style="text-align: center; padding: 15px; background: white; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                    <div style="font-size: 2em; font-weight: bold; color: #8b5cf6;">${withBC}</div>
                    <div style="color: #6b7280; font-size: 0.9em; margin-top: 5px;">Birth Certs</div>
                </div>
            </div>
            
            <!-- Action Buttons -->
            <div style="padding: 20px; background: #f9fafb; border-bottom: 1px solid #e5e7eb; display: flex; gap: 10px; flex-wrap: wrap;">
                <button onclick="printTeamRoster('${association}', '${league}', ${year}, '${teamName}', '${division}')" style="flex: 1; min-width: 150px; background: #3b82f6; color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 8px;">
                    <span style="font-size: 1.2em;">🖨️</span> Print Roster
                </button>
                <button onclick="exportTeamToExcel('${association}', '${league}', ${year}, '${teamName}', '${division}')" style="flex: 1; min-width: 150px; background: #10b981; color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 8px;">
                    <span style="font-size: 1.2em;">📊</span> Export Excel
                </button>
                <button onclick="emailTeamContacts('${association}', '${league}', ${year}, '${teamName}')" style="flex: 1; min-width: 150px; background: #8b5cf6; color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 8px;">
                    <span style="font-size: 1.2em;">✉️</span> Email Parents
                </button>
            </div>
            
            <!-- Coaches Section -->
            ${teamCoaches.length > 0 ? `
            <div style="padding: 20px; border-bottom: 1px solid #e5e7eb;">
                <h3 style="margin: 0 0 15px 0; color: #1f2937; display: flex; align-items: center; gap: 10px;">
                    <span style="font-size: 1.5em;">👨‍🏫</span> Coaching Staff
                </h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px;">
                    ${teamCoaches.map(coach => `
                        <div style="background: #f9fafb; padding: 15px; border-radius: 8px; border: 2px solid #e5e7eb;">
                            <div style="font-weight: 600; font-size: 1.1em; color: #1f2937; margin-bottom: 5px;">
                                ${coach.firstName} ${coach.lastName}
                            </div>
                            ${coach.phone ? `<div style="color: #6b7280; font-size: 0.9em;">📞 ${formatPhone(coach.phone)}</div>` : ''}
                            ${coach.email ? `<div style="color: #6b7280; font-size: 0.9em;">✉️ ${coach.email}</div>` : ''}
                        </div>
                    `).join('')}
                </div>
            </div>
            ` : ''}
            
            <!-- Players Grid -->
            <div style="padding: 20px;">
                <h3 style="margin: 0 0 15px 0; color: #1f2937; display: flex; align-items: center; gap: 10px;">
                    <span style="font-size: 1.5em;">👥</span> Player Roster
                </h3>
                
                ${teamPlayers.length === 0 ? `
                    <p style="text-align: center; color: #6b7280; padding: 40px;">No players found for this team.</p>
                ` : `
                    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 15px;">
                        ${teamPlayers.sort((a, b) => (a.unifNum || 999) - (b.unifNum || 999)).map(player => `
                            <div style="background: white; border: 2px solid #e5e7eb; border-radius: 12px; padding: 15px; transition: all 0.2s; cursor: pointer;" onmouseover="this.style.borderColor='#3b82f6'; this.style.boxShadow='0 4px 12px rgba(59,130,246,0.2)'" onmouseout="this.style.borderColor='#e5e7eb'; this.style.boxShadow='none'" onclick="viewPlayer('${player.id}')">
                                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 10px;">
                                    <div style="flex: 1;">
                                        <div style="font-size: 1.3em; font-weight: 700; color: #1f2937;">
                                            #${player.unifNum || '?'}
                                        </div>
                                    </div>
                                    <div style="background: ${player.status === 'inactive' ? '#ef4444' : '#10b981'}; color: white; padding: 3px 8px; border-radius: 12px; font-size: 0.75em; font-weight: 600;">
                                        ${player.status === 'inactive' ? 'INACTIVE' : 'ACTIVE'}
                                    </div>
                                </div>
                                <div style="font-weight: 600; font-size: 1.1em; color: #1f2937; margin-bottom: 8px;">
                                    ${player.firstName} ${player.lastName}
                                </div>
                                <div style="display: grid; gap: 4px; font-size: 0.9em; color: #6b7280;">
                                    <div>🎂 Age: ${player.age || 'N/A'}</div>
                                    <div>📅 DOB: ${player.dob || 'N/A'}</div>
                                    ${player.phone ? `<div>📞 ${formatPhone(player.phone)}</div>` : ''}
                                    ${player.email ? `<div style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">✉️ ${player.email}</div>` : ''}
                                    <div style="margin-top: 5px; padding-top: 5px; border-top: 1px solid #e5e7eb;">
                                        ${player.bc && player.bc.toLowerCase() !== 'n' ? '✅ BC' : '❌ BC'} | 
                                        ${player.cbcControl ? '✅ CBC' : '❌ CBC'}
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                `}
            </div>
            
            <!-- Footer -->
            <div style="padding: 20px; background: #f9fafb; border-top: 1px solid #e5e7eb; text-align: center; color: #6b7280; border-radius: 0 0 16px 16px;">
                <p style="margin: 0;">CBC Baseball Management System | ${teamFullName} | ${year}</p>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

function closeTeamRosterModal() {
    const modal = document.getElementById('team-roster-modal');
    if (modal) modal.remove();
}

// Table sorting state
let currentSortColumn = 'name';
let currentSortDirection = 'asc';

function sortTable(column) {
    // Toggle direction if clicking same column
    if (currentSortColumn === column) {
        currentSortDirection = currentSortDirection === 'asc' ? 'desc' : 'asc';
    } else {
        currentSortColumn = column;
        currentSortDirection = 'asc';
    }
    
    // Just sort the full players array - filters will be applied when displayPlayers is called
    let sortedPlayers = [...players];
    
    // Sort the players
    sortedPlayers.sort((a, b) => {
        let aVal, bVal;
        
        switch(column) {
            case 'name':
                aVal = `${a.lastName} ${a.firstName}`.toLowerCase();
                bVal = `${b.lastName} ${b.firstName}`.toLowerCase();
                break;
            case 'association':
                aVal = (a.association || '').toLowerCase();
                bVal = (b.association || '').toLowerCase();
                break;
            case 'league':
                aVal = (a.league || '').toLowerCase();
                bVal = (b.league || '').toLowerCase();
                break;
            case 'age':
                aVal = parseInt(a.age) || 0;
                bVal = parseInt(b.age) || 0;
                return currentSortDirection === 'asc' ? aVal - bVal : bVal - aVal;
            case 'dob':
                aVal = new Date(a.dob || '1900-01-01');
                bVal = new Date(b.dob || '1900-01-01');
                return currentSortDirection === 'asc' ? aVal - bVal : bVal - aVal;
            case 'status':
                aVal = (a.status || 'active').toLowerCase();
                bVal = (b.status || 'active').toLowerCase();
                break;
            default:
                aVal = '';
                bVal = '';
        }
        
        // String comparison
        if (typeof aVal === 'string') {
            if (currentSortDirection === 'asc') {
                return aVal.localeCompare(bVal);
            } else {
                return bVal.localeCompare(aVal);
            }
        }
        
        return 0;
    });
    
    // Update the display
    displayPlayers(sortedPlayers);
    
    // Update column headers to show sort direction
    updateSortIndicators(column);
}

function updateSortIndicators(activeColumn) {
    // Reset all headers
    const headers = {
        'name': 'Name',
        'association': 'Association',
        'league': 'Team',
        'age': 'Age',
        'dob': 'DOB',
        'status': 'Status'
    };
    
    // Update each header
    document.querySelectorAll('#player-database th[onclick^="sortTable"]').forEach(th => {
        const match = th.getAttribute('onclick').match(/sortTable\('(.+?)'\)/);
        if (match) {
            const col = match[1];
            const arrow = col === activeColumn 
                ? (currentSortDirection === 'asc' ? ' ▲' : ' ▼')
                : ' ↕';
            th.innerHTML = headers[col] + arrow;
        }
    });
}

// ============================================================================
// MANUAL PLAYER ENTRY
// ============================================================================

function showAddPlayerForm() {
    const associations = ["Chester", "Clover Hill", "Colonial Heights", "Gates", "Gordon", "Hening",
        "Jacobs", "Matoaca", "Midlothian", "Moseley", "Old Hundred", "Providence",
        "Salem", "Scott", "Smith", "Spring Run", "Swift Creek", "Wells", "Woolridge"];
    
    const formHTML = `
        <div id="add-player-modal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); display: flex; align-items: center; justify-content: center; z-index: 1000; overflow-y: auto; padding: 20px;">
            <div style="background: white; border-radius: 12px; max-width: 900px; width: 100%; max-height: 90vh; overflow-y: auto; padding: 30px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
                <h2 style="margin: 0 0 20px 0; color: #1f2937;">➕ Add New Player</h2>
                
                <form id="manual-player-form" onsubmit="submitManualPlayer(event)" style="display: grid; gap: 20px;">
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">First Name *</label>
                            <input type="text" name="firstName" required style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Last Name *</label>
                            <input type="text" name="lastName" required style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 100px 1fr; gap: 15px;">
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">MI</label>
                            <input type="text" name="middleInitial" maxlength="1" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Date of Birth *</label>
                            <input type="date" name="dob" required style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Player #</label>
                            <input type="text" name="playerNum" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Uniform #</label>
                            <input type="text" name="unifNum" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                    </div>
                    
                    <div>
                        <label style="display: block; font-weight: 600; margin-bottom: 5px;">Address</label>
                        <input type="text" name="address" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 2fr 1fr 100px; gap: 15px;">
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">City</label>
                            <input type="text" name="city" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">State</label>
                            <input type="text" name="state" value="VA" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">ZIP</label>
                            <input type="text" name="zip" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Phone</label>
                            <input type="tel" name="phone" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Email</label>
                            <input type="email" name="email" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px;">
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Association *</label>
                            <select name="association" required style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                                <option value="">Select...</option>
                                ${associations.map(a => `<option value="${a}">${a}</option>`).join('')}
                            </select>
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">League *</label>
                            <select name="league" required style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                                <option value="">Select...</option>
                                <option value="T-Ball">T-Ball</option>
                                <option value="Pee Wee">Pee Wee</option>
                                <option value="Shetland">Shetland</option>
                                <option value="Pinto">Pinto</option>
                                <option value="Mustang">Mustang</option>
                                <option value="Bronco">Bronco</option>
                                <option value="Pony">Pony</option>
                            </select>
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Year *</label>
                            <input type="number" name="year" value="2026" required style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Team Name (Coach Last Name)</label>
                            <input type="text" name="teamName" placeholder="e.g., Burkey" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Division (for Mustang/Bronco/Pony)</label>
                            <select name="division" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                                <option value="">None</option>
                                <option value="American">American</option>
                                <option value="National">National</option>
                            </select>
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">CBC Control #</label>
                            <input type="text" name="cbcControl" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Birth Certificate</label>
                            <input type="text" name="bc" placeholder="Y/N or number" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                    </div>
                    
                    <div>
                        <label style="display: block; font-weight: 600; margin-bottom: 5px;">Notes</label>
                        <textarea name="notes" rows="2" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;"></textarea>
                    </div>
                    
                    <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 10px;">
                        <button type="button" onclick="closeAddPlayerForm()" style="background: #6b7280; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 500;">Cancel</button>
                        <button type="submit" style="background: #3b82f6; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 500;">✅ Add Player</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', formHTML);
}

function closeAddPlayerForm() {
    const modal = document.getElementById('add-player-modal');
    if (modal) modal.remove();
}

function submitManualPlayer(event) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    const dob = formData.get('dob');
    const player = {
        id: generatePlayerId(),
        playerNum: formData.get('playerNum') || '',
        unifNum: formData.get('unifNum') || '',
        firstName: formData.get('firstName'),
        middleInitial: formData.get('middleInitial') || '',
        lastName: formData.get('lastName'),
        address: formData.get('address') || '',
        city: formData.get('city') || '',
        state: formData.get('state') || 'VA',
        zip: formData.get('zip') || '',
        phone: formData.get('phone') || '',
        dob: dob,
        age: calculateLeagueAge(dob),
        association: formData.get('association'),
        league: formData.get('league'),
        year: parseInt(formData.get('year')),
        teamName: formData.get('teamName') || '',
        division: formData.get('division') || '',
        cbcControl: formData.get('cbcControl') || '',
        bc: formData.get('bc') || '',
        freeAgent: '',
        travelPlayer: '',
        notes: formData.get('notes') || '',
        email: formData.get('email') || '',
        
        // Auto-set status based on year being added
        status: (() => {
            const currentYear = new Date().getFullYear();
            const playerYear = parseInt(formData.get('year'));
            return playerYear >= currentYear ? 'active' : 'inactive';
        })(),
        
        lastPlayedYear: parseInt(formData.get('year')),
        seasons: [{
            year: parseInt(formData.get('year')),
            league: formData.get('league'),
            playerNum: formData.get('playerNum') || '',
            unifNum: formData.get('unifNum') || '',
            age: calculateLeagueAge(dob),
            teamName: formData.get('teamName') || '',
            division: formData.get('division') || ''
        }],
        addedDate: new Date().toISOString()
    };
    
    players.push(player);
    saveData();
    updateDashboard();
    displayPlayers(players);
    populateFilters();
    
    closeAddPlayerForm();
    alert(`✅ ${player.firstName} ${player.lastName} has been added to the database!`);
}

function editPlayer(playerId) {
    const player = players.find(p => p.id === playerId);
    if (!player) return;
    
    const associations = ["Chester", "Clover Hill", "Colonial Heights", "Gates", "Gordon", "Hening",
        "Jacobs", "Matoaca", "Midlothian", "Moseley", "Old Hundred", "Providence",
        "Salem", "Scott", "Smith", "Spring Run", "Swift Creek", "Wells", "Woolridge"];
    
    const formHTML = `
        <div id="edit-player-modal" style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); display: flex; align-items: center; justify-content: center; z-index: 1000; overflow-y: auto; padding: 20px;">
            <div style="background: white; border-radius: 12px; max-width: 900px; width: 100%; max-height: 90vh; overflow-y: auto; padding: 30px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
                <h2 style="margin: 0 0 20px 0; color: #1f2937;">✏️ Edit Player: ${player.firstName} ${player.lastName}</h2>
                
                <form id="edit-player-form" onsubmit="submitEditPlayer(event, '${player.id}')" style="display: grid; gap: 20px;">
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">First Name *</label>
                            <input type="text" name="firstName" value="${player.firstName}" required style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Last Name *</label>
                            <input type="text" name="lastName" value="${player.lastName}" required style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 100px 1fr; gap: 15px;">
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">MI</label>
                            <input type="text" name="middleInitial" value="${player.middleInitial || ''}" maxlength="1" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Date of Birth *</label>
                            <input type="date" name="dob" value="${player.dob}" required style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Player #</label>
                            <input type="text" name="playerNum" value="${player.playerNum || ''}" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Uniform #</label>
                            <input type="text" name="unifNum" value="${player.unifNum || ''}" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                    </div>
                    
                    <div>
                        <label style="display: block; font-weight: 600; margin-bottom: 5px;">Address</label>
                        <input type="text" name="address" value="${player.address || ''}" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 2fr 1fr 100px; gap: 15px;">
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">City</label>
                            <input type="text" name="city" value="${player.city || ''}" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">State</label>
                            <input type="text" name="state" value="${player.state || 'VA'}" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">ZIP</label>
                            <input type="text" name="zip" value="${player.zip || ''}" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Phone</label>
                            <input type="tel" name="phone" value="${player.phone || ''}" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Email</label>
                            <input type="email" name="email" value="${player.email || ''}" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px;">
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Association *</label>
                            <select name="association" required style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                                ${associations.map(a => `<option value="${a}" ${player.association === a ? 'selected' : ''}>${a}</option>`).join('')}
                            </select>
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">League *</label>
                            <select name="league" required style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                                <option value="T-Ball" ${player.league === 'T-Ball' ? 'selected' : ''}>T-Ball</option>
                                <option value="Pee Wee" ${player.league === 'Pee Wee' ? 'selected' : ''}>Pee Wee</option>
                                <option value="Shetland" ${player.league === 'Shetland' ? 'selected' : ''}>Shetland</option>
                                <option value="Pinto" ${player.league === 'Pinto' ? 'selected' : ''}>Pinto</option>
                                <option value="Mustang" ${player.league === 'Mustang' ? 'selected' : ''}>Mustang</option>
                                <option value="Bronco" ${player.league === 'Bronco' ? 'selected' : ''}>Bronco</option>
                                <option value="Pony" ${player.league === 'Pony' ? 'selected' : ''}>Pony</option>
                            </select>
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Year *</label>
                            <input type="number" name="year" value="${player.year}" required style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Team Name (Coach Last Name)</label>
                            <input type="text" name="teamName" value="${player.teamName || ''}" placeholder="e.g., Burkey" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Division (for Mustang/Bronco/Pony)</label>
                            <select name="division" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                                <option value="" ${!player.division ? 'selected' : ''}>None</option>
                                <option value="American" ${player.division === 'American' ? 'selected' : ''}>American</option>
                                <option value="National" ${player.division === 'National' ? 'selected' : ''}>National</option>
                            </select>
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">CBC Control #</label>
                            <input type="text" name="cbcControl" value="${player.cbcControl || ''}" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                        <div>
                            <label style="display: block; font-weight: 600; margin-bottom: 5px;">Birth Certificate</label>
                            <input type="text" name="bc" value="${player.bc || ''}" placeholder="Y/N or number" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">
                        </div>
                    </div>
                    
                    <div>
                        <label style="display: block; font-weight: 600; margin-bottom: 5px;">Notes</label>
                        <textarea name="notes" rows="2" style="width: 100%; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px;">${player.notes || ''}</textarea>
                    </div>
                    
                    <div style="display: flex; gap: 10px; justify-content: flex-end; margin-top: 10px;">
                        <button type="button" onclick="closeEditPlayerForm()" style="background: #6b7280; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 500;">Cancel</button>
                        <button type="submit" style="background: #3b82f6; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 500;">💾 Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', formHTML);
}

function closeEditPlayerForm() {
    const modal = document.getElementById('edit-player-modal');
    if (modal) modal.remove();
}

function submitEditPlayer(event, playerId) {
    event.preventDefault();
    const form = event.target;
    const formData = new FormData(form);
    
    const player = players.find(p => p.id === playerId);
    if (!player) return;
    
    const dob = formData.get('dob');
    
    // Update player data
    player.firstName = formData.get('firstName');
    player.lastName = formData.get('lastName');
    player.middleInitial = formData.get('middleInitial') || '';
    player.dob = dob;
    player.age = calculateLeagueAge(dob);
    player.playerNum = formData.get('playerNum') || '';
    player.unifNum = formData.get('unifNum') || '';
    player.address = formData.get('address') || '';
    player.city = formData.get('city') || '';
    player.state = formData.get('state') || 'VA';
    player.zip = formData.get('zip') || '';
    player.phone = formData.get('phone') || '';
    player.email = formData.get('email') || '';
    player.association = formData.get('association');
    player.league = formData.get('league');
    player.year = parseInt(formData.get('year'));
    player.teamName = formData.get('teamName') || '';
    player.division = formData.get('division') || '';
    player.cbcControl = formData.get('cbcControl') || '';
    player.bc = formData.get('bc') || '';
    player.notes = formData.get('notes') || '';
    
    // Update most recent season if exists
    if (player.seasons && player.seasons.length > 0) {
        const latestSeason = player.seasons[player.seasons.length - 1];
        latestSeason.playerNum = player.playerNum;
        latestSeason.unifNum = player.unifNum;
        latestSeason.age = player.age;
        latestSeason.league = player.league;
        latestSeason.year = player.year;
        latestSeason.teamName = player.teamName;
        latestSeason.division = player.division;
    }
    
    saveData();
    updateDashboard();
    displayPlayers(players);
    
    closeEditPlayerForm();
    alert(`✅ ${player.firstName} ${player.lastName} has been updated!`);
}

// ============================================================================
// DOCUMENT MANAGEMENT SYSTEM
// ============================================================================

function handleDocumentUpload(files) {
    Array.from(files).forEach(file => {
        if (file.type.startsWith('image/') || file.type === 'application/pdf') {
            const reader = new FileReader();
            reader.onload = (e) => {
                const doc = {
                    id: 'DOC' + Date.now() + Math.random().toString(36).substr(2, 9),
                    name: file.name,
                    type: document.getElementById('doc-type').value,
                    fileType: file.type,
                    data: e.target.result,
                    playerId: document.getElementById('doc-player-link').value || null,
                    uploadDate: new Date().toISOString(),
                    size: file.size
                };
                
                documents.push(doc);
                saveData();
                displayDocuments();
                alert(`✅ Document "${file.name}" uploaded successfully!`);
            };
            reader.readAsDataURL(file);
        } else {
            alert(`❌ Unsupported file type: ${file.name}`);
        }
    });
}

function displayDocuments() {
    const container = document.getElementById('documents-list');
    
    // Update player link dropdown
    const playerSelect = document.getElementById('doc-player-link');
    if (playerSelect) {
        playerSelect.innerHTML = '<option value="">-- No Player Link --</option>';
        players.forEach(p => {
            const option = document.createElement('option');
            option.value = p.id;
            option.textContent = `${p.firstName} ${p.lastName} (${p.association} - ${p.league})`;
            playerSelect.appendChild(option);
        });
    }
    
    if (documents.length === 0) {
        container.innerHTML = '<p class="empty-state">No documents uploaded yet</p>';
        return;
    }
    
    container.innerHTML = '<h3>Uploaded Documents</h3>';
    
    const docTypes = {
        'birth-cert': 'Birth Certificates',
        'waiver': 'Waivers',
        'registration': 'Registration Forms',
        'other': 'Other Documents'
    };
    
    Object.keys(docTypes).forEach(type => {
        const typeDocs = documents.filter(d => d.type === type);
        if (typeDocs.length > 0) {
            container.innerHTML += `<h4>${docTypes[type]} (${typeDocs.length})</h4>`;
            container.innerHTML += '<div class="documents-grid">';
            
            typeDocs.forEach(doc => {
                const player = doc.playerId ? players.find(p => p.id === doc.playerId) : null;
                const sizeKB = (doc.size / 1024).toFixed(1);
                
                container.innerHTML += `
                    <div class="document-card">
                        <div class="doc-icon">${doc.fileType.includes('pdf') ? '📄' : '🖼️'}</div>
                        <div class="doc-info">
                            <strong>${doc.name}</strong>
                            <small>${sizeKB} KB</small>
                            ${player ? `<small>Player: ${player.firstName} ${player.lastName}</small>` : ''}
                        </div>
                        <div class="doc-actions">
                            <button class="btn-small" onclick="viewDocument('${doc.id}')">View</button>
                            <button class="btn-small btn-danger" onclick="deleteDocument('${doc.id}')">Delete</button>
                        </div>
                    </div>
                `;
            });
            
            container.innerHTML += '</div>';
        }
    });
}

function viewDocument(docId) {
    const doc = documents.find(d => d.id === docId);
    if (doc) {
        const win = window.open('', '_blank');
        if (doc.fileType === 'application/pdf') {
            win.document.write(`<iframe width="100%" height="100%" src="${doc.data}"></iframe>`);
        } else {
            win.document.write(`<img src="${doc.data}" style="max-width: 100%;">`);
        }
    }
}

function deleteDocument(docId) {
    if (confirm('Are you sure you want to delete this document?')) {
        documents = documents.filter(d => d.id !== docId);
        saveData();
        displayDocuments();
    }
}

// ============================================================================
// PDF REPORT GENERATION
// ============================================================================

function generateMasterReport() {
    // Use Excel export instead (already implemented)
    generateMasterRoster();
}

console.log('🏏 CBC Baseball Management System loaded');
console.log('📊 Players:', players.length);
console.log('📄 Documents:', documents.length);
console.log('🎯 Ready to import team rosters!');

// ============================================================================
// PRINT FUNCTIONS
// ============================================================================

function printTeamRoster(association, league, year, teamName = '', division = '') {
    const teamPlayers = players.filter(p => {
        const matchesBasic = p.association === association && p.league === league && p.year === year;
        if (teamName && division) {
            return matchesBasic && p.teamName === teamName && p.division === division;
        } else if (teamName) {
            return matchesBasic && p.teamName === teamName;
        }
        return matchesBasic;
    }).sort((a, b) => (a.unifNum || 999) - (b.unifNum || 999));
    
    const teamCoaches = coaches.filter(c => 
        c.association === association && c.league === league && c.year === year
    );
    
    const teamFullName = teamName && division 
        ? `${association} ${league} ${division} - ${teamName}`
        : teamName 
            ? `${association} ${league} - ${teamName}`
            : `${association} ${league}`;
    
    const printWindow = window.open('', '', 'width=800,height=600');
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>${teamFullName} Roster - ${year}</title>
            <style>
                @media print {
                    body { margin: 0; padding: 20px; }
                    .no-print { display: none; }
                    @page { margin: 0.5in; }
                }
                body {
                    font-family: Arial, sans-serif;
                    max-width: 800px;
                    margin: 0 auto;
                    padding: 20px;
                }
                .header {
                    text-align: center;
                    border-bottom: 3px solid #3b82f6;
                    padding-bottom: 15px;
                    margin-bottom: 20px;
                }
                .header h1 {
                    margin: 0;
                    color: #1f2937;
                    font-size: 24px;
                }
                .header p {
                    margin: 5px 0;
                    color: #6b7280;
                }
                .stats {
                    display: flex;
                    justify-content: space-around;
                    margin: 20px 0;
                    padding: 15px;
                    background: #f3f4f6;
                    border-radius: 8px;
                }
                .stat {
                    text-align: center;
                }
                .stat-number {
                    font-size: 24px;
                    font-weight: bold;
                    color: #3b82f6;
                }
                .stat-label {
                    font-size: 12px;
                    color: #6b7280;
                }
                .coaches {
                    margin: 20px 0;
                    padding: 15px;
                    background: #fef3c7;
                    border-radius: 8px;
                }
                .coaches h2 {
                    margin: 0 0 10px 0;
                    font-size: 16px;
                }
                .coach {
                    margin: 5px 0;
                    padding: 5px 0;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 20px;
                }
                th {
                    background: #3b82f6;
                    color: white;
                    padding: 10px;
                    text-align: left;
                    font-size: 12px;
                }
                td {
                    padding: 8px;
                    border-bottom: 1px solid #e5e7eb;
                    font-size: 11px;
                }
                tr:hover {
                    background: #f9fafb;
                }
                .status-badge {
                    display: inline-block;
                    padding: 2px 8px;
                    border-radius: 12px;
                    font-size: 10px;
                    font-weight: bold;
                }
                .active { background: #d1fae5; color: #065f46; }
                .inactive { background: #fee2e2; color: #991b1b; }
                .check { color: #10b981; }
                .cross { color: #ef4444; }
                .footer {
                    margin-top: 30px;
                    padding-top: 15px;
                    border-top: 1px solid #e5e7eb;
                    text-align: center;
                    color: #6b7280;
                    font-size: 11px;
                }
                .no-print {
                    text-align: center;
                    margin: 20px 0;
                }
                .print-btn {
                    background: #3b82f6;
                    color: white;
                    border: none;
                    padding: 12px 30px;
                    border-radius: 6px;
                    cursor: pointer;
                    font-size: 14px;
                    font-weight: 600;
                }
            </style>
        </head>
        <body>
            <div class="no-print">
                <button class="print-btn" onclick="window.print()">🖨️ Print Roster</button>
            </div>
            
            <div class="header">
                <h1>⚾ ${teamFullName}</h1>
                <p>${year} Season Official Roster</p>
                <p>Chesterfield Baseball Clubs</p>
            </div>
            
            <div class="stats">
                <div class="stat">
                    <div class="stat-number">${teamPlayers.length}</div>
                    <div class="stat-label">Total Players</div>
                </div>
                <div class="stat">
                    <div class="stat-number">${teamCoaches.length}</div>
                    <div class="stat-label">Coaches</div>
                </div>
                <div class="stat">
                    <div class="stat-number">${teamPlayers.filter(p => p.bc && p.bc.toLowerCase() !== 'n').length}</div>
                    <div class="stat-label">Birth Certificates</div>
                </div>
            </div>
            
            ${teamCoaches.length > 0 ? `
            <div class="coaches">
                <h2>👨‍🏫 Coaching Staff</h2>
                ${teamCoaches.map(c => `
                    <div class="coach">
                        <strong>${c.firstName} ${c.lastName}</strong>
                        ${c.phone ? ` | 📞 ${formatPhone(c.phone)}` : ''}
                        ${c.email ? ` | ✉️ ${c.email}` : ''}
                    </div>
                `).join('')}
            </div>
            ` : ''}
            
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Player Name</th>
                        <th>Age</th>
                        <th>DOB</th>
                        <th>Phone</th>
                        <th>BC</th>
                        <th>CBC</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    ${teamPlayers.map(p => `
                        <tr>
                            <td><strong>${p.unifNum || '?'}</strong></td>
                            <td><strong>${p.firstName} ${p.lastName}</strong></td>
                            <td>${p.age || 'N/A'}</td>
                            <td>${p.dob || 'N/A'}</td>
                            <td>${p.phone ? formatPhone(p.phone) : 'N/A'}</td>
                            <td class="${p.bc && p.bc.toLowerCase() !== 'n' ? 'check' : 'cross'}">
                                ${p.bc && p.bc.toLowerCase() !== 'n' ? '✓' : '✗'}
                            </td>
                            <td class="${p.cbcControl ? 'check' : 'cross'}">
                                ${p.cbcControl ? '✓' : '✗'}
                            </td>
                            <td>
                                <span class="status-badge ${p.status === 'inactive' ? 'inactive' : 'active'}">
                                    ${p.status === 'inactive' ? 'INACTIVE' : 'ACTIVE'}
                                </span>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
            
            <div class="footer">
                <p>Generated on ${new Date().toLocaleString()} | CBC Baseball Management System</p>
                <p>${teamFullName} | ${year} Season</p>
            </div>
        </body>
        </html>
    `);
    printWindow.document.close();
}

function exportTeamToExcel(association, league, year, teamName = '', division = '') {
    const teamPlayers = players.filter(p => {
        const matchesBasic = p.association === association && p.league === league && p.year === year;
        if (teamName && division) {
            return matchesBasic && p.teamName === teamName && p.division === division;
        } else if (teamName) {
            return matchesBasic && p.teamName === teamName;
        }
        return matchesBasic;
    }).sort((a, b) => (a.unifNum || 999) - (b.unifNum || 999));
    
    const teamFullName = teamName && division 
        ? `${association} ${league} ${division} - ${teamName}`
        : teamName 
            ? `${association} ${league} - ${teamName}`
            : `${association} ${league}`;
    
    const wb = XLSX.utils.book_new();
    
    const exportData = teamPlayers.map(p => ({
        'Uniform #': p.unifNum || '',
        'Player #': p.playerNum || '',
        'First Name': p.firstName,
        'MI': p.middleInitial || '',
        'Last Name': p.lastName,
        'DOB': p.dob || '',
        'Age': p.age || '',
        'Address': p.address || '',
        'City': p.city || '',
        'State': p.state || '',
        'ZIP': p.zip || '',
        'Phone': p.phone || '',
        'Email': p.email || '',
        'CBC Control #': p.cbcControl || '',
        'Birth Certificate': p.bc || '',
        'Status': p.status || 'active',
        'Team': p.teamName || '',
        'Division': p.division || ''
    }));
    
    const ws = XLSX.utils.json_to_sheet(exportData);
    XLSX.utils.book_append_sheet(wb, ws, 'Roster');
    
    const filename = `${teamFullName.replace(/\s+/g, '-')}-${year}.xlsx`;
    XLSX.writeFile(wb, filename);
}

function emailTeamContacts(association, league, year, teamName = '') {
    const teamPlayers = players.filter(p => {
        const matchesBasic = p.association === association && p.league === league && p.year === year;
        return teamName ? matchesBasic && p.teamName === teamName : matchesBasic;
    });
    
    const emails = teamPlayers
        .filter(p => p.email)
        .map(p => p.email)
        .join(';');
    
    if (!emails) {
        alert('No email addresses found for this team!');
        return;
    }
    
    const teamFullName = teamName ? `${association} ${league} - ${teamName}` : `${association} ${league}`;
    const subject = `${teamFullName} - ${year} Season Update`;
    const body = `Hello ${teamFullName} Families,\n\n[Your message here]\n\nBest regards,\nCBC Baseball`;
    
    window.location.href = `mailto:${emails}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

function printPlayerCard(playerId) {
    const player = players.find(p => p.id === playerId);
    if (!player) return;
    
    const printWindow = window.open('', '', 'width=600,height=800');
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>${player.firstName} ${player.lastName} - Player Card</title>
            <style>
                @media print {
                    body { margin: 0; padding: 10px; }
                    .no-print { display: none; }
                }
                body {
                    font-family: Arial, sans-serif;
                    max-width: 500px;
                    margin: 0 auto;
                    padding: 20px;
                }
                .card {
                    border: 3px solid #3b82f6;
                    border-radius: 12px;
                    padding: 20px;
                    background: white;
                }
                .header {
                    text-align: center;
                    padding: 15px;
                    background: linear-gradient(135deg, #3b82f6, #1e40af);
                    color: white;
                    border-radius: 8px;
                    margin-bottom: 20px;
                }
                .jersey-number {
                    font-size: 72px;
                    font-weight: bold;
                    line-height: 1;
                    margin: 10px 0;
                }
                .player-name {
                    font-size: 24px;
                    font-weight: bold;
                    margin: 10px 0;
                }
                .team-info {
                    font-size: 14px;
                    opacity: 0.9;
                }
                .info-section {
                    margin: 15px 0;
                    padding: 15px;
                    background: #f9fafb;
                    border-radius: 8px;
                }
                .info-row {
                    display: flex;
                    justify-content: space-between;
                    padding: 8px 0;
                    border-bottom: 1px solid #e5e7eb;
                }
                .info-row:last-child {
                    border-bottom: none;
                }
                .label {
                    font-weight: 600;
                    color: #6b7280;
                }
                .value {
                    color: #1f2937;
                }
                .footer {
                    text-align: center;
                    margin-top: 20px;
                    padding-top: 15px;
                    border-top: 1px solid #e5e7eb;
                    color: #6b7280;
                    font-size: 11px;
                }
            </style>
        </head>
        <body>
            <div class="no-print" style="text-align: center; margin-bottom: 20px;">
                <button onclick="window.print()" style="background: #3b82f6; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 600;">
                    🖨️ Print Card
                </button>
            </div>
            
            <div class="card">
                <div class="header">
                    <div class="jersey-number">#${player.unifNum || '?'}</div>
                    <div class="player-name">${player.firstName} ${player.lastName}</div>
                    <div class="team-info">${player.association} ${player.league}${player.teamName ? ` - ${player.teamName}` : ''}</div>
                    <div class="team-info">${player.year} Season</div>
                </div>
                
                <div class="info-section">
                    <div class="info-row">
                        <span class="label">Player #:</span>
                        <span class="value">${player.playerNum || 'N/A'}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Date of Birth:</span>
                        <span class="value">${player.dob || 'N/A'}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Age:</span>
                        <span class="value">${player.age || 'N/A'}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Division:</span>
                        <span class="value">${player.division || 'N/A'}</span>
                    </div>
                </div>
                
                <div class="info-section">
                    <div class="info-row">
                        <span class="label">Phone:</span>
                        <span class="value">${player.phone ? formatPhone(player.phone) : 'N/A'}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Email:</span>
                        <span class="value" style="font-size: 11px;">${player.email || 'N/A'}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Address:</span>
                        <span class="value" style="font-size: 11px;">${player.address || 'N/A'}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">City, State ZIP:</span>
                        <span class="value">${player.city || ''} ${player.state || ''} ${player.zip || ''}</span>
                    </div>
                </div>
                
                <div class="info-section">
                    <div class="info-row">
                        <span class="label">CBC Control #:</span>
                        <span class="value">${player.cbcControl || 'Not Assigned'}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Birth Certificate:</span>
                        <span class="value">${player.bc && player.bc.toLowerCase() !== 'n' ? '✓ Yes' : '✗ No'}</span>
                    </div>
                    <div class="info-row">
                        <span class="label">Status:</span>
                        <span class="value">${player.status === 'inactive' ? 'INACTIVE' : 'ACTIVE'}</span>
                    </div>
                </div>
                
                ${player.notes ? `
                <div class="info-section">
                    <div class="label" style="margin-bottom: 8px;">Notes:</div>
                    <div class="value" style="font-size: 12px; line-height: 1.5;">${player.notes}</div>
                </div>
                ` : ''}
                
                <div class="footer">
                    <p>CBC Baseball Management System</p>
                    <p>Generated on ${new Date().toLocaleString()}</p>
                </div>
            </div>
        </body>
        </html>
    `);
    printWindow.document.close();
}

function printPlayerDatabase() {
    const currentPlayers = players.filter(p => {
        const searchTerm = document.getElementById('player-search').value.toLowerCase();
        const association = document.getElementById('filter-association').value;
        const league = document.getElementById('filter-league').value;
        const year = document.getElementById('filter-year').value;
        const status = document.getElementById('filter-status').value;
        
        const matchesSearch = !searchTerm || 
            p.firstName.toLowerCase().includes(searchTerm) ||
            p.lastName.toLowerCase().includes(searchTerm) ||
            (p.email && p.email.toLowerCase().includes(searchTerm));
        
        const matchesAssociation = !association || p.association.toUpperCase() === association.toUpperCase();
        const matchesLeague = !league || p.league.toUpperCase() === league.toUpperCase();
        const matchesYear = !year || p.year === parseInt(year);
        const matchesStatus = !status || p.status === status || (!p.status && status === 'active');
        
        return matchesSearch && matchesAssociation && matchesLeague && matchesYear && matchesStatus;
    }).sort((a, b) => {
        const nameA = `${a.lastName} ${a.firstName}`.toLowerCase();
        const nameB = `${b.lastName} ${b.firstName}`.toLowerCase();
        return nameA.localeCompare(nameB);
    });
    
    if (currentPlayers.length === 0) {
        alert('No players to print with current filters!');
        return;
    }
    
    const filterInfo = [];
    const association = document.getElementById('filter-association').value;
    const league = document.getElementById('filter-league').value;
    const year = document.getElementById('filter-year').value;
    const status = document.getElementById('filter-status').value;
    
    if (association) filterInfo.push(`Association: ${association}`);
    if (league) filterInfo.push(`League: ${league}`);
    if (year) filterInfo.push(`Year: ${year}`);
    if (status) filterInfo.push(`Status: ${status}`);
    
    const filterText = filterInfo.length > 0 ? ` (${filterInfo.join(', ')})` : '';
    
    const printWindow = window.open('', '', 'width=1200,height=800');
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Player Database Report</title>
            <style>
                @media print {
                    body { margin: 0; padding: 10px; }
                    .no-print { display: none; }
                    @page { margin: 0.5in; size: landscape; }
                }
                body {
                    font-family: Arial, sans-serif;
                    margin: 0 auto;
                    padding: 20px;
                    max-width: 100%;
                }
                .header {
                    text-align: center;
                    border-bottom: 3px solid #3b82f6;
                    padding-bottom: 15px;
                    margin-bottom: 20px;
                }
                .header h1 {
                    margin: 0;
                    color: #1f2937;
                    font-size: 24px;
                }
                .header p {
                    margin: 5px 0;
                    color: #6b7280;
                    font-size: 12px;
                }
                .stats {
                    display: flex;
                    justify-content: space-around;
                    margin: 15px 0;
                    padding: 10px;
                    background: #f3f4f6;
                    border-radius: 8px;
                }
                .stat {
                    text-align: center;
                }
                .stat-number {
                    font-size: 20px;
                    font-weight: bold;
                    color: #3b82f6;
                }
                .stat-label {
                    font-size: 10px;
                    color: #6b7280;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 15px;
                    font-size: 9px;
                }
                th {
                    background: #3b82f6;
                    color: white;
                    padding: 6px 4px;
                    text-align: left;
                    font-size: 9px;
                    white-space: nowrap;
                }
                td {
                    padding: 4px;
                    border-bottom: 1px solid #e5e7eb;
                    font-size: 9px;
                }
                tr:nth-child(even) {
                    background: #f9fafb;
                }
                .status-active { 
                    background: #d1fae5; 
                    color: #065f46; 
                    padding: 2px 4px; 
                    border-radius: 3px;
                    font-size: 8px;
                    font-weight: bold;
                }
                .status-inactive { 
                    background: #fee2e2; 
                    color: #991b1b; 
                    padding: 2px 4px; 
                    border-radius: 3px;
                    font-size: 8px;
                    font-weight: bold;
                }
                .check { color: #10b981; font-weight: bold; }
                .cross { color: #ef4444; }
                .footer {
                    margin-top: 20px;
                    padding-top: 10px;
                    border-top: 1px solid #e5e7eb;
                    text-align: center;
                    color: #6b7280;
                    font-size: 9px;
                }
                .no-print {
                    text-align: center;
                    margin: 15px 0;
                }
                .print-btn {
                    background: #3b82f6;
                    color: white;
                    border: none;
                    padding: 10px 25px;
                    border-radius: 6px;
                    cursor: pointer;
                    font-size: 14px;
                    font-weight: 600;
                }
            </style>
        </head>
        <body>
            <div class="no-print">
                <button class="print-btn" onclick="window.print()">🖨️ Print Database</button>
            </div>
            
            <div class="header">
                <h1>🏏 CBC Baseball - Player Database Report</h1>
                <p>Chesterfield Baseball Clubs${filterText}</p>
                <p>Generated on ${new Date().toLocaleString()}</p>
            </div>
            
            <div class="stats">
                <div class="stat">
                    <div class="stat-number">${currentPlayers.length}</div>
                    <div class="stat-label">Total Players</div>
                </div>
                <div class="stat">
                    <div class="stat-number">${currentPlayers.filter(p => !p.status || p.status === 'active').length}</div>
                    <div class="stat-label">Active</div>
                </div>
                <div class="stat">
                    <div class="stat-number">${currentPlayers.filter(p => p.status === 'inactive').length}</div>
                    <div class="stat-label">Inactive</div>
                </div>
                <div class="stat">
                    <div class="stat-number">${currentPlayers.filter(p => !p.cbcControl).length}</div>
                    <div class="stat-label">Missing CBC#</div>
                </div>
                <div class="stat">
                    <div class="stat-number">${currentPlayers.filter(p => !p.bc || p.bc.toLowerCase() === 'n').length}</div>
                    <div class="stat-label">Missing BC</div>
                </div>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Association</th>
                        <th>League/Team</th>
                        <th>Age</th>
                        <th>DOB</th>
                        <th>CBC #</th>
                        <th>BC</th>
                        <th>Status</th>
                        <th>Phone</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    ${currentPlayers.map((p, index) => {
                        const teamDisplay = p.teamName ? `${p.league} ${p.teamName}` : p.league;
                        const divDisplay = p.division ? ` (${p.division})` : '';
                        return `
                        <tr>
                            <td>${index + 1}</td>
                            <td><strong>${p.firstName} ${p.lastName}</strong></td>
                            <td>${p.association}</td>
                            <td>${teamDisplay}${divDisplay}</td>
                            <td>${p.age || 'N/A'}</td>
                            <td>${p.dob || 'N/A'}</td>
                            <td>${p.cbcControl ? `<span style="color:#059669;font-weight:bold;">${p.cbcControl}</span>` : '<span style="color:#ef4444;">—</span>'}</td>
                            <td class="${p.bc && p.bc.toLowerCase() !== 'n' ? 'check' : 'cross'}">
                                ${p.bc && p.bc.toLowerCase() !== 'n' ? '✓' : '✗'}
                            </td>
                            <td>
                                <span class="status-${(!p.status || p.status === 'active') ? 'active' : 'inactive'}">
                                    ${(!p.status || p.status === 'active') ? 'ACTIVE' : 'INACTIVE'}
                                </span>
                            </td>
                            <td>${p.phone ? formatPhone(p.phone) : '—'}</td>
                            <td style="font-size: 8px;">${p.email || '—'}</td>
                        </tr>
                    `}).join('')}
                </tbody>
            </table>
            
            <div class="footer">
                <p>CBC Baseball Management System | Player Database Report</p>
                <p>Total Records: ${currentPlayers.length} | Generated: ${new Date().toLocaleString()}</p>
            </div>
        </body>
        </html>
    `);
    printWindow.document.close();
}

// Print Coaches Database
function printCoachesDatabase() {
    // Get current filter values
    const searchTerm = document.getElementById('coach-search').value.toLowerCase();
    const associationFilter = document.getElementById('filter-association')?.value || 'all';
    const leagueFilter = document.getElementById('filter-league')?.value || 'all';
    const yearFilter = document.getElementById('filter-year')?.value || 'all';
    
    // Filter coaches based on current filters
    let currentCoaches = [...coaches];
    
    if (searchTerm) {
        currentCoaches = currentCoaches.filter(coach => 
            coach.firstName?.toLowerCase().includes(searchTerm) ||
            coach.lastName?.toLowerCase().includes(searchTerm) ||
            coach.phone?.toLowerCase().includes(searchTerm) ||
            coach.email?.toLowerCase().includes(searchTerm) ||
            coach.association?.toLowerCase().includes(searchTerm) ||
            coach.league?.toLowerCase().includes(searchTerm)
        );
    }
    
    if (associationFilter !== 'all') {
        currentCoaches = currentCoaches.filter(coach => coach.association === associationFilter);
    }
    
    if (leagueFilter !== 'all') {
        currentCoaches = currentCoaches.filter(coach => coach.league === leagueFilter);
    }
    
    if (yearFilter !== 'all') {
        currentCoaches = currentCoaches.filter(coach => coach.year === yearFilter);
    }
    
    // Sort by last name, then first name
    currentCoaches.sort((a, b) => {
        const lastNameCompare = (a.lastName || '').localeCompare(b.lastName || '');
        if (lastNameCompare !== 0) return lastNameCompare;
        return (a.firstName || '').localeCompare(b.firstName || '');
    });
    
    // Build filter info text
    let filterInfo = [];
    if (associationFilter !== 'all') filterInfo.push(`Association: ${associationFilter}`);
    if (leagueFilter !== 'all') filterInfo.push(`League: ${leagueFilter}`);
    if (yearFilter !== 'all') filterInfo.push(`Year: ${yearFilter}`);
    if (searchTerm) filterInfo.push(`Search: "${searchTerm}"`);
    const filterText = filterInfo.length > 0 ? ` (Filtered: ${filterInfo.join(', ')})` : '';
    
    // Calculate quick stats
    const totalCoaches = currentCoaches.length;
    const missingPhone = currentCoaches.filter(c => !c.phone || c.phone.trim() === '').length;
    const missingEmail = currentCoaches.filter(c => !c.email || c.email.trim() === '').length;
    const missingAddress = currentCoaches.filter(c => !c.address || c.address.trim() === '').length;
    
    // Open print window
    const printWindow = window.open('', '', 'width=1100,height=800');
    
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>CBC Coaches Database</title>
            <style>
                @page {
                    size: landscape;
                    margin: 0.5in;
                }
                
                @media print {
                    body {
                        margin: 0;
                        padding: 15px;
                        font-family: Arial, sans-serif;
                        font-size: 9px;
                    }
                    
                    .no-print {
                        display: none !important;
                    }
                    
                    table {
                        page-break-inside: auto;
                    }
                    
                    tr {
                        page-break-inside: avoid;
                        page-break-after: auto;
                    }
                }
                
                body {
                    font-family: Arial, sans-serif;
                    margin: 0;
                    padding: 15px;
                    font-size: 9px;
                }
                
                .header {
                    text-align: center;
                    margin-bottom: 15px;
                    border-bottom: 2px solid #003366;
                    padding-bottom: 10px;
                }
                
                .header h1 {
                    margin: 0;
                    font-size: 18px;
                    color: #003366;
                }
                
                .header p {
                    margin: 3px 0;
                    font-size: 10px;
                    color: #666;
                }
                
                .stats-bar {
                    display: flex;
                    justify-content: space-around;
                    margin-bottom: 15px;
                    background: #f0f0f0;
                    padding: 8px;
                    border-radius: 4px;
                }
                
                .stat-item {
                    text-align: center;
                }
                
                .stat-value {
                    font-size: 14px;
                    font-weight: bold;
                    color: #003366;
                }
                
                .stat-label {
                    font-size: 8px;
                    color: #666;
                    margin-top: 2px;
                }
                
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 15px;
                }
                
                th {
                    background: #003366;
                    color: white;
                    padding: 6px 4px;
                    text-align: left;
                    font-size: 9px;
                    font-weight: bold;
                    border: 1px solid #002244;
                }
                
                td {
                    padding: 5px 4px;
                    border: 1px solid #ddd;
                    font-size: 8px;
                }
                
                tbody tr:nth-child(even) {
                    background: #f9f9f9;
                }
                
                tbody tr:hover {
                    background: #e8f4f8;
                }
                
                .footer {
                    text-align: center;
                    margin-top: 15px;
                    padding-top: 10px;
                    border-top: 1px solid #ccc;
                    font-size: 8px;
                    color: #666;
                }
                
                .missing-data {
                    color: #cc0000;
                    font-style: italic;
                }
                
                .coach-num {
                    font-weight: bold;
                    color: #003366;
                }
                
                @media print {
                    .stats-bar {
                        -webkit-print-color-adjust: exact;
                        print-color-adjust: exact;
                    }
                    
                    th {
                        -webkit-print-color-adjust: exact;
                        print-color-adjust: exact;
                    }
                    
                    tbody tr:nth-child(even) {
                        -webkit-print-color-adjust: exact;
                        print-color-adjust: exact;
                    }
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>🏆 CBC COACHES DATABASE</h1>
                <p>Central Baseball Conference | Coaches Contact Information</p>
                <p>${filterText}</p>
            </div>
            
            <div class="stats-bar">
                <div class="stat-item">
                    <div class="stat-value">${totalCoaches}</div>
                    <div class="stat-label">Total Coaches</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value" style="color: ${missingPhone > 0 ? '#cc0000' : '#28a745'};">${missingPhone}</div>
                    <div class="stat-label">Missing Phone</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value" style="color: ${missingEmail > 0 ? '#cc0000' : '#28a745'};">${missingEmail}</div>
                    <div class="stat-label">Missing Email</div>
                </div>
                <div class="stat-item">
                    <div class="stat-value" style="color: ${missingAddress > 0 ? '#cc0000' : '#28a745'};">${missingAddress}</div>
                    <div class="stat-label">Missing Address</div>
                </div>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th style="width: 5%;">Coach #</th>
                        <th style="width: 12%;">Name</th>
                        <th style="width: 10%;">Association</th>
                        <th style="width: 8%;">League</th>
                        <th style="width: 6%;">Year</th>
                        <th style="width: 10%;">Phone</th>
                        <th style="width: 15%;">Email</th>
                        <th style="width: 20%;">Address</th>
                        <th style="width: 14%;">City, State ZIP</th>
                    </tr>
                </thead>
                <tbody>
                    ${currentCoaches.map(coach => `
                        <tr>
                            <td class="coach-num">${coach.coachNum || '-'}</td>
                            <td><strong>${coach.lastName || ''}, ${coach.firstName || ''}</strong></td>
                            <td>${coach.association || '-'}</td>
                            <td>${coach.league || '-'}</td>
                            <td>${coach.year || '-'}</td>
                            <td>${coach.phone || '<span class="missing-data">Missing</span>'}</td>
                            <td style="font-size: 7px;">${coach.email || '<span class="missing-data">Missing</span>'}</td>
                            <td>${coach.address || '<span class="missing-data">Missing</span>'}</td>
                            <td>${coach.city || ''}, ${coach.state || ''} ${coach.zip || ''}</td>
                        </tr>
                    `).join('')}
                    ${currentCoaches.length === 0 ? `
                        <tr>
                            <td colspan="9" style="text-align: center; padding: 20px; color: #999;">
                                No coaches match the current filters.
                            </td>
                        </tr>
                    ` : ''}
                </tbody>
            </table>
            
            <div class="footer">
                <p>CBC Baseball Management System | Coaches Database Report</p>
                <p>Total Records: ${currentCoaches.length} | Generated: ${new Date().toLocaleString()}</p>
            </div>
        </body>
        </html>
    `);
    printWindow.document.close();
}


