# CBC Baseball Management System

**Chesterfield Baseball Clubs - Administrative Database**

A web-based system to manage player rosters, team data, and documents for CBC Baseball.

---

## 🎯 Features (FULLY IMPLEMENTED)

### ✅ Core Features:
- **Dashboard** - Overview of players, teams, and associations
- **Excel Import** - Drag & drop CBC roster template files
- **Player Database** - Searchable table with filters (View/Edit/Delete)
- **Coaches Tab** - Separate database for coach information
- **Team Management** - View teams by association and league
- **Document Management** - Upload and organize PDFs, birth certificates, waivers
- **Excel Reports** - Generate master rosters, summaries, age group reports
- **Data Storage** - Automatic save in browser (localStorage)
- **Backup & Restore** - Export/import all data for thumb drive portability
- **Manual Entry** - Add individual players without Excel import
- **Filtering** - By association, league, year, status
- **Search** - Find players by name or email

### 📊 Report Types:
- Master Roster (all players by association)
- Association Summary (counts, stats, missing data)
- Age Group Report (players by league)
- Missing Data Report (incomplete player records)
- Team Rosters (by team)
- Birth Certificate Tracking (compliance report)
- Contact List (phone/email directory)

---

## 🚀 How to Use

### Getting Started:

1. **Open the Application**
   - Open `index.html` in any modern web browser
   - Chrome, Firefox, Safari, or Edge recommended

2. **Import Team Rosters** (Real Data)
   - Go to "Import Rosters" tab
   - Drag & drop Excel files (.xlsx, .xlsm) or click to browse
   - System automatically extracts player data
   - Check "Player Database" tab to see imported players

3. **OR Generate Sample Data** (For Testing)
   - Go to "Import Rosters" tab
   - Click "Generate Sample Data" button
   - Check "Player Database" tab to see sample players

---

## 📝 File Naming Convention (IMPORTANT!)

To ensure data is imported correctly without manual intervention, **name your Excel files using this standardized format:**

### Format: `YYYY-cbc-association-league-coach.xlsm`

**Examples:**
- `2025-cbc-scott-pinto-fischer.xlsm` 
  - Year: 2025, Association: Scott, League: Pinto, Team: Fischer
- `2025-cbc-woolridge-bronco-burkey.xlsm`
  - Year: 2025, Association: Woolridge, League: Bronco, Team: Burkey
- `2025-cbc-jacobs-mustang-edwards.xlsm`
  - Year: 2025, Association: Jacobs, League: Mustang, Team: Edwards

**Why this matters:**
- The system parses the filename to auto-populate Association, League, Year, and Team Name
- Prevents confusion when multiple teams from the same association are uploaded
- Eliminates manual prompts for division and team information
- Ensures consistent data entry across all imports

**What happens if I don't follow this format?**
- The system will fall back to reading data from the Excel file's header cells (B3, B4, B5)
- You may be prompted to enter team name and division manually
- Risk of team names being detected incorrectly

**Filename Rules:**
- Use lowercase for everything except the year
- Use hyphens (-) to separate parts
- Coach name should be the coach's last name (becomes the team name)
- File extension can be `.xlsm`, `.xlsx`, or `.xls`

---

## 📋 Association List

### Active Associations (19):
- Chester (Curtis Elem)
- Clover Hill (Grange Hall)
- Colonial Heights
- Gates
- Gordon
- Hening
- Jacobs
- Matoaca
- Midlothian (Watkins Elem)
- Moseley
- Old Hundred
- Providence
- Salem
- Scott
- Smith
- Spring Run
- Swift Creek
- Wells
- Woolridge

### Age Groups/Leagues:
- T-Ball
- Pee Wee
- Shetland
- Pinto
- Mustang
- Bronco
- Pony

---

## 📊 Data Structure

### Player Fields:
- Player #, Uniform #
- First Name, MI, Last Name
- Address, City, State, ZIP
- Phone, Email
- Date of Birth, Age
- Association, League, Year
- CBC Control #
- Birth Certificate (BC)
- Free Agent (FA)
- Travel Player
- Association Notes

### Expected Excel Format:
The system is designed to read the CBC roster template with columns:
- Row 7: Headers
- Row 8+: Player data
- Association, League, Year in cells B3, B4, B5

---

## 💾 Data Storage

**Current:** Browser localStorage
- Data persists between sessions
- Stored locally on your computer
- No server/database needed
- Can handle thousands of players
- Export to Excel anytime for backup

**Important Notes:**
- Data is stored in your browser's localStorage
- Export regularly to Excel for backups
- Clearing browser data will erase stored information
- Works completely offline

---

## 🔧 Technical Details

### Files:
- `index.html` - Main application interface
- `app.js` - Application logic and data management
- `styles.css` - Visual styling
- `xlsx.full.min.js` - SheetJS library for Excel files
- `jspdf.umd.min.js` - jsPDF library for PDF generation
- `FileSaver.min.js` - FileSaver.js for file downloads

### Browser Compatibility:
- Chrome/Edge 90+
- Firefox 88+
- Safari 14+

### Fully Integrated Libraries:
- ✅ SheetJS (xlsx.js) - Excel file reading/writing
- ✅ jsPDF - PDF generation
- ✅ FileSaver.js - File downloads

---

## 📝 Workflow

### For the Secretary:

1. **Receive Team Rosters**
   - Each association submits Excel file(s)
   - One file per team

2. **Import to System**
   - Go to "Import Rosters" tab
   - Drag & drop or select Excel files
   - System extracts player data

3. **Verify Data**
   - Check "Player Database" tab
   - Use filters to review by association
   - Search for specific players

4. **Track Submissions**
   - Dashboard shows which associations submitted
   - Green checkmark = submitted
   - Gray = pending

5. **Generate Reports**
   - Master roster (all players)
   - Association summaries
   - Age group reports
   - Missing data reports

---

## 🎓 Tips

### Searching Players:
- Type player name, email, or any text
- Filters narrow results instantly
- Click "Clear Filters" to reset

### Organizing Data:
- Filter by association to see one group
- Filter by league to see age divisions
- Filter by year for historical data

### Best Practices:
- Import rosters as they arrive
- Review data after each import
- Generate reports weekly
- Back up data regularly (export to Excel)

---

## 🐛 Troubleshooting

**Problem:** Sample data button doesn't work
- **Solution:** Refresh the page and try again

**Problem:** Data disappeared
- **Solution:** Check if browser cache was cleared; export data regularly

**Problem:** Can't import Excel files (Phase 1)
- **Solution:** Excel import requires Phase 2 libraries; use sample data for testing

**Problem:** Filters not working
- **Solution:** Clear filters and try again; check if data exists

---

## 📞 Support

For questions or issues:
- Email: cvcwvuaa@gmail.com
- Contact: Tim Casten (804) 566-8058

---

## 🔮 Roadmap

### ✅ Phase 1 - COMPLETE:
- Basic interface
- Excel import/export
- Data storage
- Filtering and search
- Document upload/management
- Sample data
- All report types

### 🔜 Phase 2 (Future Enhancements):
- Online registration forms
- Birth certificate OCR
- Email integration
- Cloud storage option
- Multi-user access
- Mobile app version
- Automated data validation

---

**Version:** 2.0.0 (All Features Complete)  
**Last Updated:** October 29, 2025  
**Developer:** Tim Casten
